# Simbeye Pharmacy — Digital Platform (MVP)

A working, full-stack pharmacy ordering platform for Simbeye Pharmacy: browse the catalogue,
add prescription and non-prescription items to a cart, check out with a location-based delivery
fee (or in-store collection), pay by Mobile Money / Card / Cash, upload a prescription for
pharmacist review, track an order's status, and manage all of it from a role-based admin
dashboard.

This is Version 1 / "Launch" from the product plan: a functioning pharmacy business, not a
brochure website. It is a real, runnable codebase — not a mockup.

## What's actually here

- **Customer site**: home, shop with search/category filters, product detail, cart, one-page
  checkout (customer details → delivery zone or collection → prescription upload if needed →
  payment method → live total → place order), order confirmation, and phone-gated order tracking.
- **Admin dashboard**: staff login, a "Today" overview (orders, sales, low stock, expiring
  batches, pending prescriptions), order management with an enforced status workflow, a
  pharmacist prescription-review queue that cascades to order status, product management, and
  delivery-zone management — the pharmacy can change delivery fees and add zones from the
  dashboard with **zero code changes**, exactly as specified.
- **Server-authoritative pricing**: the client never dictates a price, a delivery fee, or a
  stock level. Every order is priced and stock-checked from the database inside a single
  database transaction at the moment of purchase.
- **A pharmacist safety gate**: any order containing a prescription-only item is automatically
  routed to a `pharmacist_review` status and cannot move forward until a pharmacist approves the
  uploaded prescription from the admin dashboard.

## What's stubbed (and clearly marked as such in the code)

Nothing here should be mistaken for a finished, launch-ready system. Specifically:

- **Payments.** There is no real payment gateway integration. `POST /orders/:orderNumber/simulate-payment`
  is a stub that mimics what an async gateway callback would look like, so the checkout UX
  reads correctly end-to-end. Before real launch, wire this to a Tanzania-compatible gateway —
  Azampay, Selcom, Flutterwave, or DPO Pay were the options named in the original product plan.
  **No card details are collected or stored anywhere in this codebase.**
- **WhatsApp / SMS automation.** The `wa.me/<number>` deep links (floating button, checkout,
  order confirmation, tracking page) are real and work today with zero backend setup. Automated
  status-change messages ("your order is out for delivery") are only written to a
  `notifications_log` table as a stub — real delivery needs the WhatsApp Business API plus an
  SMS provider (Beem Africa or Africa's Talking were named in the plan).
- **Staff password hashing.** Uses SHA-256 for simplicity in this demo. This is **not**
  production-grade — swap in bcrypt or argon2 before real deployment.
- **The WhatsApp number.** `255700000000` is a placeholder used throughout
  (`client/src/components/Layout.tsx`, `Checkout.tsx`, `TrackOrder.tsx`, `OrderConfirmation.tsx`).
  Replace it with the pharmacy's real WhatsApp Business number before going live.
- **Product photography.** Products use colored initials as placeholders — no real product
  images are included.

## Architecture

```
client/   React + TypeScript + Vite + Tailwind CSS  (customer site + admin dashboard)
server/   Express + TypeScript + better-sqlite3      (REST API)
```

**Why SQLite instead of the Supabase/Postgres stack from the original plan:** this build
environment has no Docker daemon and no live Supabase project to connect to. `better-sqlite3`
was used as a pragmatic stand-in so the whole app runs standalone with zero external services —
but the schema (`server/src/db.ts`) is deliberately written to mirror a normal Postgres table
design (same table names, same columns, same relationships) so migrating to real Supabase later
is a re-point of the connection layer, not a redesign. See "Migrating to Supabase/Postgres" below.

### Server-side order flow

1. Client sends `{ items: [{productId, qty}], fulfillmentType, deliveryZoneId, ... }` — no
   prices.
2. The server looks up each product's **current** price and stock, the **current** delivery
   zone fee, recomputes the subtotal/total from scratch, and rejects the order if any item is
   out of stock or the zone is contact-only.
3. If any item requires a prescription, the order is created with `order_status =
   'pharmacist_review'` instead of `'received'`.
4. All of this happens inside one `better-sqlite3` transaction, so it's atomic even under
   concurrent orders.

### Order status state machine

```
received → pharmacist_review → confirmed → preparing → out_for_delivery → delivered
                              ↘ confirmed → preparing → ready_for_collection → collected
(any non-terminal status) → cancelled
```

Enforced server-side in `server/src/routes/admin.ts` (`VALID_TRANSITIONS`) — the admin UI can
only offer the transitions the server will actually accept.

## Running it locally

Requires Node.js 18+.

### 1. Start the API server

```bash
cd server
npm install
npm run seed   # creates & seeds the SQLite database — safe to re-run any time to reset demo data
npm run dev    # http://localhost:4000
```

### 2. Start the client (in a second terminal)

```bash
cd client
npm install
npm run dev    # http://localhost:5173
```

The Vite dev server proxies `/api` and `/uploads` to `http://localhost:4000`, so open
`http://localhost:5173` and everything just works together — no CORS configuration needed in
development.

### Demo logins

| Role | Email | Password |
|---|---|---|
| Super admin | `admin@simbeye.co.tz` | `simbeye2026` |
| Pharmacist | `pharmacist@simbeye.co.tz` | `simbeye2026` |

Admin dashboard: `http://localhost:5173/admin/login`

### Demo delivery zones (seeded exactly as specified)

| Zone | Fee |
|---|---|
| Zone A — Nearby | TZS 2,000 |
| Zone B — Moderate distance | TZS 3,000 |
| Zone C — Further | TZS 5,000 |
| Outside delivery area | Contact pharmacy (no online delivery) |

Edit these any time from **Admin → Delivery Zones** — no code changes required.

### Resetting demo data

`npm run seed` (from `server/`) wipes and re-seeds everything: 13 categories, 80 products, the
4 delivery zones above, and the 2 staff accounts. Two products are deliberately seeded at low/zero
stock (Ceftriaxone Injection, Insulin) and some product batches are seeded with near expiry dates,
so the low-stock and expiring-batch admin views have something to show out of the box.

## Migrating to Supabase/Postgres

The schema in `server/src/db.ts` was written to look like a normal Postgres schema on purpose.
To move off SQLite:

1. Create the same tables in a Supabase Postgres project (the SQL is nearly a direct port —
   swap `INTEGER PRIMARY KEY AUTOINCREMENT` for `SERIAL PRIMARY KEY` / `BIGINT GENERATED ALWAYS
   AS IDENTITY`, and `TEXT` timestamps for `TIMESTAMPTZ`).
2. Replace the `better-sqlite3` calls in `server/src/db.ts`, `helpers.ts`, and each file under
   `server/src/routes/` with the Supabase JS client or `pg`. The query shapes carry over almost
   unchanged since the columns are identical.
3. Move file storage for prescription uploads (currently local disk under
   `server/uploads/prescriptions/`) to Supabase Storage.
4. Swap the SHA-256 password hashing for Supabase Auth (or bcrypt if keeping a custom staff
   table).

## Project structure

```
server/
  src/
    db.ts                 # schema (mirrors a Postgres/Supabase design)
    helpers.ts             # auth, order numbers, notification-log stub
    seed.ts                 # demo data generator
    routes/
      catalogue.ts          # public: categories, products, delivery zones
      orders.ts              # public: create order, track order, simulate payment
      prescriptions.ts        # public: upload prescription file
      admin.ts                 # staff-only: dashboard, products, zones, orders, prescriptions
client/
  src/
    lib/                   # api.ts (fetch wrappers), types.ts, format.ts
    store/CartContext.tsx  # cart state, persisted to localStorage
    components/            # Layout, ProductCard, StockBadge
    pages/                 # customer-facing pages
    pages/admin/           # staff dashboard pages
```

## Regulatory note

This build includes the legal-framing safeguards discussed during planning: prescription-only
items are gated behind pharmacist review rather than being auto-dispensed, and the previously
delivered purchase order already reflects the narrower framing for mifepristone/post-abortion
care stock (physician-authorised, not open elective retail). Before a real launch, verify current
Tanzanian pharmacy, medicines-advertising, dispensing, e-commerce, and data-protection
requirements — this codebase does not constitute legal or regulatory advice.
