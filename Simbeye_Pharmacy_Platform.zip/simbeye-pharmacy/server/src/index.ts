import express from "express";
import cors from "cors";
import path from "path";
import "./db"; // ensure schema is created
import { catalogueRouter } from "./routes/catalogue";
import { ordersRouter } from "./routes/orders";
import { prescriptionsRouter } from "./routes/prescriptions";
import { adminRouter } from "./routes/admin";

const app = express();
const PORT = process.env.PORT || 4000;

app.use(cors());
app.use(express.json());
app.use("/uploads", express.static(path.join(__dirname, "..", "uploads")));

app.get("/api/health", (_req, res) => res.json({ ok: true, service: "Simbeye Pharmacy API" }));

app.use("/api", catalogueRouter);
app.use("/api", ordersRouter);
app.use("/api", prescriptionsRouter);
app.use("/api/admin", adminRouter);

app.use((err: any, _req: any, res: any, _next: any) => {
  console.error(err);
  res.status(500).json({ error: err.message || "Server error" });
});

app.listen(PORT, () => {
  console.log(`Simbeye Pharmacy API running on http://localhost:${PORT}`);
});
