import crypto from "crypto";
import { db } from "./db";

export function hashPassword(pw: string) {
  return crypto.createHash("sha256").update(pw).digest("hex");
}

export function makeToken() {
  return crypto.randomBytes(24).toString("hex");
}

export function nextOrderNumber(): string {
  const row = db.prepare(`SELECT COUNT(*) AS n FROM orders`).get() as { n: number };
  const seq = row.n + 1024; // start numbering from SP-1024 for a nicer look
  return `SP-${seq}`;
}

// Simulated notification — logs what would be sent via WhatsApp/SMS in
// production. Wire this to the WhatsApp Business API + an SMS provider
// (e.g. Beem Africa, Africa's Talking) to make it real.
export function logNotification(orderId: number, channel: "whatsapp" | "sms", message: string) {
  db.prepare(
    `INSERT INTO notifications_log (order_id, channel, message) VALUES (?, ?, ?)`
  ).run(orderId, channel, message);
}

export function requireStaff(req: any, res: any, next: any) {
  const token = req.headers["authorization"]?.replace("Bearer ", "");
  if (!token) return res.status(401).json({ error: "Not authenticated" });
  const session = db
    .prepare(`SELECT s.*, st.name, st.role, st.email FROM sessions s JOIN staff st ON st.id = s.staff_id WHERE token = ?`)
    .get(token) as any;
  if (!session) return res.status(401).json({ error: "Invalid or expired session" });
  req.staff = { id: session.staff_id, name: session.name, role: session.role, email: session.email };
  next();
}
