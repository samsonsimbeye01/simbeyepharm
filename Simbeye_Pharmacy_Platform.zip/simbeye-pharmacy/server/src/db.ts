import Database from "better-sqlite3";
import path from "path";
import fs from "fs";

const dataDir = path.join(__dirname, "..", "data");
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });

const dbPath = path.join(dataDir, "simbeye.db");
export const db = new Database(dbPath);
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");

// ---------------------------------------------------------------------
// Schema. This mirrors the Postgres/Supabase table design in the product
// plan (categories, products, batches, delivery_zones, customers,
// addresses, orders, order_items, prescriptions, staff, notifications_log)
// so migrating to a real Supabase/Postgres backend later is a re-point,
// not a redesign. SQLite is used here so the whole app runs standalone
// with zero external services for this MVP build.
// ---------------------------------------------------------------------
db.exec(`
CREATE TABLE IF NOT EXISTS categories (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  slug TEXT NOT NULL UNIQUE,
  icon TEXT,
  sort_order INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS products (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  generic_name TEXT,
  category_id INTEGER REFERENCES categories(id),
  strength TEXT,
  dosage_form TEXT,
  pack_size TEXT,
  price INTEGER NOT NULL,              -- TZS, integer (no decimals in circulation)
  purchase_price INTEGER,
  stock_qty INTEGER NOT NULL DEFAULT 0,
  reorder_level INTEGER NOT NULL DEFAULT 10,
  requires_prescription INTEGER NOT NULL DEFAULT 0, -- 0/1
  image_color TEXT DEFAULT '#0F2C59',   -- placeholder swatch color, no real product photos in this MVP
  description TEXT,
  active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS product_batches (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  product_id INTEGER NOT NULL REFERENCES products(id),
  batch_number TEXT NOT NULL,
  expiry_date TEXT NOT NULL,           -- ISO date
  quantity INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS delivery_zones (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  description TEXT,
  fee INTEGER NOT NULL,                -- TZS; 0 means free; NULL fee handled via is_contact_only
  is_contact_only INTEGER NOT NULL DEFAULT 0, -- "Outside delivery area — contact pharmacy"
  active INTEGER NOT NULL DEFAULT 1,
  sort_order INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS customers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  phone TEXT NOT NULL UNIQUE,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS orders (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  order_number TEXT NOT NULL UNIQUE,
  customer_id INTEGER REFERENCES customers(id),
  customer_name TEXT NOT NULL,
  customer_phone TEXT NOT NULL,
  fulfillment_type TEXT NOT NULL CHECK (fulfillment_type IN ('delivery','collection')),
  delivery_zone_id INTEGER REFERENCES delivery_zones(id),
  delivery_fee INTEGER NOT NULL DEFAULT 0,
  address_text TEXT,
  landmark TEXT,
  delivery_instructions TEXT,
  subtotal INTEGER NOT NULL,
  total INTEGER NOT NULL,
  payment_method TEXT NOT NULL CHECK (payment_method IN ('mobile_money','card','cash')),
  payment_status TEXT NOT NULL DEFAULT 'pending' CHECK (payment_status IN ('pending','paid','failed')),
  order_status TEXT NOT NULL DEFAULT 'received' CHECK (
    order_status IN ('received','pharmacist_review','confirmed','preparing','out_for_delivery','ready_for_collection','delivered','collected','cancelled')
  ),
  has_prescription_items INTEGER NOT NULL DEFAULT 0,
  notes TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS order_items (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  order_id INTEGER NOT NULL REFERENCES orders(id),
  product_id INTEGER NOT NULL REFERENCES products(id),
  product_name TEXT NOT NULL,          -- snapshot at time of order
  requires_prescription INTEGER NOT NULL DEFAULT 0,
  qty INTEGER NOT NULL,
  unit_price INTEGER NOT NULL,
  line_total INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS prescriptions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  order_id INTEGER REFERENCES orders(id),
  customer_phone TEXT NOT NULL,
  file_path TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','approved','rejected')),
  pharmacist_notes TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  reviewed_at TEXT
);

CREATE TABLE IF NOT EXISTS staff (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('super_admin','pharmacist','inventory_manager','cashier')),
  active INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS sessions (
  token TEXT PRIMARY KEY,
  staff_id INTEGER NOT NULL REFERENCES staff(id),
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Stub log for SMS/WhatsApp notifications. In production this table is
-- written to by a real integration (WhatsApp Business API + an SMS
-- provider such as Beem Africa / Africa's Talking); here we just log
-- what WOULD have been sent, at each order-status transition.
CREATE TABLE IF NOT EXISTS notifications_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  order_id INTEGER REFERENCES orders(id),
  channel TEXT NOT NULL,               -- 'whatsapp' | 'sms'
  message TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_products_category ON products(category_id);
CREATE INDEX IF NOT EXISTS idx_products_active ON products(active);
CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(order_status);
CREATE INDEX IF NOT EXISTS idx_orders_number ON orders(order_number);
`);

export default db;
