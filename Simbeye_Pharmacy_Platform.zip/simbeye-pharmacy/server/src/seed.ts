import { db } from "./db";
import crypto from "crypto";

// ---------------------------------------------------------------------
// Seed data. Products are a curated, representative subset drawn from
// the Simbeye Pharmacy opening purchase order (real NEMLIT-grounded
// medicines + OTC + devices, TZS pricing consistent with that workbook)
// -- not the full 400-SKU order, just enough to populate a realistic
// catalogue for demoing the platform end to end.
// ---------------------------------------------------------------------

function reset() {
  db.exec(`
    DELETE FROM notifications_log;
    DELETE FROM prescriptions;
    DELETE FROM order_items;
    DELETE FROM orders;
    DELETE FROM customers;
    DELETE FROM product_batches;
    DELETE FROM products;
    DELETE FROM delivery_zones;
    DELETE FROM categories;
    DELETE FROM sessions;
    DELETE FROM staff;
  `);
}

function hashPassword(pw: string) {
  return crypto.createHash("sha256").update(pw).digest("hex");
}

reset();

const categories = [
  { name: "Pain & Fever", slug: "pain-fever", icon: "🌡️" },
  { name: "Cold & Flu", slug: "cold-flu", icon: "🤧" },
  { name: "Antibiotics (Prescription)", slug: "antibiotics", icon: "💊" },
  { name: "Malaria Treatment", slug: "malaria", icon: "🦟" },
  { name: "Diabetes & Heart", slug: "diabetes-heart", icon: "❤️" },
  { name: "Maternal & Child Health", slug: "maternal-child", icon: "🤱" },
  { name: "Vitamins & Supplements", slug: "vitamins", icon: "🍊" },
  { name: "Digestive Health", slug: "digestive", icon: "🍽️" },
  { name: "Skin Care", slug: "skin-care", icon: "🧴" },
  { name: "First Aid & Wound Care", slug: "first-aid", icon: "🩹" },
  { name: "Sexual & Reproductive Health", slug: "reproductive-health", icon: "🌸" },
  { name: "Medical Devices", slug: "devices", icon: "🩺" },
  { name: "Personal & Baby Care", slug: "personal-care", icon: "🧸" },
];

const insCat = db.prepare(
  `INSERT INTO categories (name, slug, icon, sort_order) VALUES (?, ?, ?, ?)`
);
const catId: Record<string, number> = {};
categories.forEach((c, i) => {
  const info = insCat.run(c.name, c.slug, c.icon, i);
  catId[c.slug] = info.lastInsertRowid as number;
});

type P = [
  name: string,
  generic: string | null,
  cat: string,
  form: string,
  price: number,
  stock: number,
  reorder: number,
  rx: 0 | 1,
  color: string
];

const NAVY = "#0F2C59", TEAL = "#00A896", RED = "#D64550", VIOLET = "#6B21A8", BLUE = "#0066CC", GREEN = "#059669";

const products: P[] = [
  // Pain & Fever
  ["Paracetamol 500mg", "Paracetamol", "pain-fever", "Tab, 100s", 5000, 40, 20, 0, TEAL],
  ["Paracetamol Paediatric Syrup", "Paracetamol", "pain-fever", "Syrup, 100ml", 4500, 25, 10, 0, TEAL],
  ["Ibuprofen 400mg", "Ibuprofen", "pain-fever", "Tab, 30s", 6500, 30, 15, 0, TEAL],
  ["Diclofenac Gel", "Diclofenac", "pain-fever", "Gel, 30g", 8500, 18, 8, 0, TEAL],
  ["Tramadol 50mg", "Tramadol", "pain-fever", "Cap, 10s", 9000, 10, 6, 1, TEAL],
  ["Aspirin 300mg", "Acetylsalicylic Acid", "pain-fever", "Tab, 100s", 3500, 20, 10, 0, TEAL],

  // Cold & Flu
  ["Cetirizine 10mg", "Cetirizine", "cold-flu", "Tab, 10s", 4500, 35, 15, 0, NAVY],
  ["Chlorpheniramine 4mg", "Chlorpheniramine", "cold-flu", "Tab, 100s", 2500, 30, 15, 0, NAVY],
  ["Cough Syrup", "Dextromethorphan", "cold-flu", "Syrup, 100ml", 6500, 22, 10, 0, NAVY],
  ["Vicks VapoRub", "Menthol/Camphor", "cold-flu", "Ointment, 25g", 6000, 20, 10, 0, NAVY],
  ["Throat Lozenges", "Menthol/Honey", "cold-flu", "Pack of 12", 3000, 25, 10, 0, NAVY],

  // Antibiotics (Rx)
  ["Amoxicillin 500mg", "Amoxicillin", "antibiotics", "Cap, 21s", 6500, 25, 12, 1, BLUE],
  ["Amoxicillin + Clavulanic Acid 625mg", "Co-amoxiclav", "antibiotics", "Tab, 14s", 12000, 12, 6, 1, BLUE],
  ["Azithromycin 500mg", "Azithromycin", "antibiotics", "Tab, 3s", 8500, 20, 10, 1, BLUE],
  ["Ciprofloxacin 500mg", "Ciprofloxacin", "antibiotics", "Tab, 10s", 7500, 18, 8, 1, BLUE],
  ["Doxycycline 100mg", "Doxycycline", "antibiotics", "Cap, 10s", 5500, 15, 8, 1, BLUE],
  ["Metronidazole 400mg", "Metronidazole", "antibiotics", "Tab, 21s", 5000, 22, 10, 1, BLUE],
  ["Ceftriaxone 1g Injection", "Ceftriaxone", "antibiotics", "Vial", 15000, 8, 4, 1, BLUE],

  // Malaria
  ["Artemether/Lumefantrine (ALu)", "Artemether/Lumefantrine", "malaria", "Course pack", 6000, 40, 20, 0, GREEN],
  ["Dihydroartemisinin + Piperaquine", "DHA-PPQ", "malaria", "Course pack", 7000, 20, 10, 0, GREEN],
  ["Malaria Rapid Test Kit", null, "malaria", "Single test", 4000, 30, 15, 0, GREEN],

  // Diabetes & Heart
  ["Metformin 500mg", "Metformin", "diabetes-heart", "Tab, 60s", 6000, 25, 12, 1, RED],
  ["Amlodipine 10mg", "Amlodipine", "diabetes-heart", "Tab, 30s", 5500, 22, 10, 1, RED],
  ["Losartan 50mg", "Losartan", "diabetes-heart", "Tab, 30s", 6500, 15, 8, 1, RED],
  ["Atorvastatin 20mg", "Atorvastatin", "diabetes-heart", "Tab, 30s", 8500, 14, 8, 1, RED],
  ["Glibenclamide 5mg", "Glibenclamide", "diabetes-heart", "Tab, 30s", 4500, 12, 8, 1, RED],
  ["Insulin (Soluble/NPH)", "Insulin", "diabetes-heart", "Vial", 15000, 6, 4, 1, RED],

  // Maternal & Child Health
  ["Ferrous Salts + Folic Acid", "Iron + Folic Acid", "maternal-child", "Tab, 30s", 3500, 30, 15, 0, VIOLET],
  ["Antenatal Multivitamins", null, "maternal-child", "Tab, 30s", 7000, 20, 10, 0, VIOLET],
  ["Oral Rehydration Salts (ORS)", null, "maternal-child", "Sachet", 1800, 50, 20, 0, VIOLET],
  ["Zinc Sulfate Syrup", "Zinc Sulfate", "maternal-child", "Syrup, 60ml", 4500, 18, 10, 0, VIOLET],
  ["Gripe Water", null, "maternal-child", "Syrup, 100ml", 4000, 15, 8, 0, VIOLET],
  ["Clean Home Delivery Kit", null, "maternal-child", "Kit", 8000, 10, 5, 0, VIOLET],

  // Vitamins & Supplements
  ["Multivitamin + Multimineral", null, "vitamins", "Tab, 30s", 8000, 25, 12, 0, TEAL],
  ["Vitamin B-Complex", null, "vitamins", "Tab, 30s", 5000, 20, 10, 0, TEAL],
  ["Vitamin C 100mg", "Ascorbic Acid", "vitamins", "Tab, 100s", 4000, 25, 12, 0, TEAL],
  ["Calcium + Vitamin D3", null, "vitamins", "Tab, 30s", 7500, 15, 8, 0, TEAL],
  ["Cod Liver Oil / Omega-3", null, "vitamins", "Cap, 30s", 9000, 12, 6, 0, TEAL],

  // Digestive Health
  ["Omeprazole 20mg", "Omeprazole", "digestive", "Cap, 14s", 6000, 22, 10, 0, NAVY],
  ["Antacid Suspension", "Al/Mg Hydroxide", "digestive", "Suspension, 200ml", 5500, 18, 8, 0, NAVY],
  ["Loperamide 2mg", "Loperamide", "digestive", "Cap, 12s", 4000, 20, 10, 0, NAVY],
  ["Bisacodyl 5mg", "Bisacodyl", "digestive", "Tab, 20s", 3500, 12, 6, 0, NAVY],
  ["Domperidone 10mg", "Domperidone", "digestive", "Tab, 20s", 5000, 12, 6, 0, NAVY],

  // Skin Care
  ["Clotrimazole Cream", "Clotrimazole", "skin-care", "Cream, 20g", 5000, 18, 8, 0, RED],
  ["Hydrocortisone Cream 1%", "Hydrocortisone", "skin-care", "Cream, 15g", 5500, 15, 8, 0, RED],
  ["Benzyl Benzoate Lotion", "Benzyl Benzoate", "skin-care", "Lotion, 100ml", 6000, 10, 5, 0, RED],
  ["Petroleum Jelly", null, "skin-care", "Jar, 100g", 3000, 20, 10, 0, RED],
  ["Sunscreen SPF 30+", null, "skin-care", "Lotion, 50ml", 12000, 10, 5, 0, RED],

  // First Aid & Wound Care
  ["Adhesive Plasters (assorted)", null, "first-aid", "Box", 5000, 25, 12, 0, GREEN],
  ["Gauze Swabs", null, "first-aid", "Pack of 100", 8000, 15, 8, 0, GREEN],
  ["Crepe Bandage", null, "first-aid", "Roll", 6000, 20, 10, 0, GREEN],
  ["Povidone-Iodine 10%", null, "first-aid", "Solution, 100ml", 6000, 20, 10, 0, GREEN],
  ["Cotton Wool Roll", null, "first-aid", "500g", 6000, 15, 8, 0, GREEN],
  ["Ethanol/Alcohol Hand Rub", null, "first-aid", "500ml", 6000, 25, 12, 0, GREEN],
  ["Complete First Aid Kit", null, "first-aid", "Box", 35000, 8, 4, 0, GREEN],
  ["Disposable Examination Gloves", null, "first-aid", "Box of 100", 12000, 15, 8, 0, GREEN],
  ["Surgical / Face Masks", null, "first-aid", "Box of 50", 10000, 20, 10, 0, GREEN],

  // Sexual & Reproductive Health
  ["Male Condoms (Durex, Trust, Lifestyle)", null, "reproductive-health", "Pack of 3", 3000, 40, 15, 0, VIOLET],
  ["Female / Internal Condoms", null, "reproductive-health", "Pack", 6000, 12, 6, 0, VIOLET],
  ["Levonorgestrel Emergency Contraceptive", "Levonorgestrel", "reproductive-health", "Tab", 6000, 15, 8, 0, VIOLET],
  ["Pregnancy Test Strip", null, "reproductive-health", "Pack of 5", 5000, 20, 10, 0, VIOLET],
  ["Sanitary Pads (Regular)", null, "reproductive-health", "Pack", 3500, 30, 15, 0, VIOLET],
  ["Vaginal Lubricating Gel", null, "reproductive-health", "Tube", 7000, 12, 6, 0, VIOLET],
  ["Clotrimazole Vaginal Pessaries", "Clotrimazole", "reproductive-health", "Pack", 8000, 10, 5, 0, VIOLET],
  ["HIV Self-Test Kit", null, "reproductive-health", "Pack of 5", 15000, 10, 5, 0, VIOLET],

  // Medical Devices
  ["Digital Thermometer", null, "devices", "Device", 8000, 15, 6, 0, NAVY],
  ["Blood Pressure Monitor (Digital)", null, "devices", "Device", 55000, 6, 3, 0, NAVY],
  ["Glucometer + 25 Strips", null, "devices", "Kit", 45000, 8, 4, 0, NAVY],
  ["Pulse Oximeter", null, "devices", "Device", 35000, 8, 4, 0, NAVY],
  ["Nebulizer (Compressor)", null, "devices", "Device", 120000, 4, 2, 0, NAVY],
  ["Adult Weighing Scale (Digital)", null, "devices", "Device", 60000, 4, 2, 0, NAVY],
  ["Foley Catheter", null, "devices", "Unit", 8000, 15, 8, 0, NAVY],
  ["Urine Collection Bag", null, "devices", "Unit", 6000, 15, 8, 0, NAVY],
  ["Nasogastric Tube (NGT)", null, "devices", "Unit", 5000, 15, 8, 0, NAVY],
  ["Oxygen Nasal Cannula", null, "devices", "Unit", 3500, 12, 6, 0, NAVY],
  ["Wheelchair (Standard Folding)", null, "devices", "Unit", 350000, 2, 1, 0, NAVY],
  ["Crutches (Adjustable Pair)", null, "devices", "Pair", 45000, 4, 2, 0, NAVY],

  // Personal & Baby Care
  ["Diaper Rash Cream", null, "personal-care", "Tube", 6000, 12, 6, 0, TEAL],
  ["Medicated Soap", null, "personal-care", "Bar", 3000, 20, 10, 0, TEAL],
  ["Intimate Cleansing Wash", null, "personal-care", "Bottle", 8000, 12, 6, 0, TEAL],
];

const insProd = db.prepare(`
  INSERT INTO products
    (name, generic_name, category_id, strength, dosage_form, pack_size, price, purchase_price, stock_qty, reorder_level, requires_prescription, image_color, active)
  VALUES (@name, @generic_name, @category_id, NULL, @dosage_form, @pack_size, @price, @purchase_price, @stock_qty, @reorder_level, @requires_prescription, @image_color, 1)
`);

const insertMany = db.transaction((rows: P[]) => {
  for (const [name, generic, cat, form, price, stock, reorder, rx, color] of rows) {
    insProd.run({
      name,
      generic_name: generic,
      category_id: catId[cat],
      dosage_form: form,
      pack_size: form,
      price,
      purchase_price: Math.round(price * 0.6),
      stock_qty: stock,
      reorder_level: reorder,
      requires_prescription: rx,
      image_color: color,
    });
  }
});
insertMany(products);

// A couple of intentionally near-zero-stock / out-of-stock products to
// demonstrate the low-stock and out-of-stock UI states.
db.prepare(`
  UPDATE products SET stock_qty = 2 WHERE name = 'Ceftriaxone 1g Injection'
`).run();
db.prepare(`
  UPDATE products SET stock_qty = 0 WHERE name = 'Insulin (Soluble/NPH)'
`).run();

// Batches for expiry-management demo
const someProducts = db.prepare(`SELECT id, name FROM products LIMIT 10`).all() as { id: number; name: string }[];
const insBatch = db.prepare(
  `INSERT INTO product_batches (product_id, batch_number, expiry_date, quantity) VALUES (?, ?, ?, ?)`
);
const today = new Date();
someProducts.forEach((p, i) => {
  const expiry = new Date(today);
  expiry.setDate(expiry.getDate() + (i % 3 === 0 ? 45 : i % 3 === 1 ? 200 : 400)); // mix of soon/far
  insBatch.run(p.id, `B${1000 + i}`, expiry.toISOString().slice(0, 10), 10 + i);
});

// Delivery zones — matches the user's own example
db.prepare(
  `INSERT INTO delivery_zones (name, description, fee, is_contact_only, active, sort_order) VALUES (?, ?, ?, ?, 1, ?)`
).run("Zone A — Nearby", "Within ~3km of the pharmacy", 2000, 0, 1);
db.prepare(
  `INSERT INTO delivery_zones (name, description, fee, is_contact_only, active, sort_order) VALUES (?, ?, ?, ?, 1, ?)`
).run("Zone B — Moderate distance", "3-8km from the pharmacy", 3000, 0, 2);
db.prepare(
  `INSERT INTO delivery_zones (name, description, fee, is_contact_only, active, sort_order) VALUES (?, ?, ?, ?, 1, ?)`
).run("Zone C — Further", "8-15km from the pharmacy", 5000, 0, 3);
db.prepare(
  `INSERT INTO delivery_zones (name, description, fee, is_contact_only, active, sort_order) VALUES (?, ?, ?, ?, 1, ?)`
).run("Outside delivery area", "Beyond 15km — contact the pharmacy directly", 0, 1, 4);

// Seed admin/staff users (demo credentials — change before any real launch)
const insStaff = db.prepare(
  `INSERT INTO staff (name, email, password_hash, role, active) VALUES (?, ?, ?, ?, 1)`
);
insStaff.run("Simbeye Super Admin", "admin@simbeye.co.tz", hashPassword("simbeye2026"), "super_admin");
insStaff.run("Duty Pharmacist", "pharmacist@simbeye.co.tz", hashPassword("simbeye2026"), "pharmacist");

console.log(`Seeded ${categories.length} categories, ${products.length} products, 4 delivery zones, 2 staff users.`);
console.log("Admin login: admin@simbeye.co.tz / simbeye2026");
