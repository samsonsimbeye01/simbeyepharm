import { Router } from "express";
import multer from "multer";
import path from "path";
import fs from "fs";
import { db } from "../db";

export const prescriptionsRouter = Router();

const uploadDir = path.join(__dirname, "..", "..", "uploads", "prescriptions");
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true });

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, uploadDir),
  filename: (_req, file, cb) => {
    const ext = path.extname(file.originalname) || ".jpg";
    cb(null, `rx_${Date.now()}_${Math.round(Math.random() * 1e6)}${ext}`);
  },
});
const upload = multer({
  storage,
  limits: { fileSize: 10 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    const ok = ["image/jpeg", "image/png", "image/jpg", "application/pdf"].includes(file.mimetype);
    if (ok) cb(null, true);
    else cb(new Error("Only JPG, PNG or PDF files are accepted."));
  },
});

prescriptionsRouter.post("/prescriptions", upload.single("file"), (req, res) => {
  const { customerPhone, orderId } = req.body as { customerPhone?: string; orderId?: string };
  if (!req.file) return res.status(400).json({ error: "No file uploaded." });
  if (!customerPhone) return res.status(400).json({ error: "Phone number is required." });

  const relativePath = `/uploads/prescriptions/${req.file.filename}`;
  const info = db
    .prepare(`INSERT INTO prescriptions (order_id, customer_phone, file_path, status) VALUES (?, ?, ?, 'pending')`)
    .run(orderId ? Number(orderId) : null, customerPhone, relativePath);

  res.status(201).json({ id: info.lastInsertRowid, filePath: relativePath, status: "pending" });
});
