import { Router } from "express";
import { db } from "../db";

export const catalogueRouter = Router();

catalogueRouter.get("/categories", (req, res) => {
  const categories = db.prepare(`SELECT * FROM categories ORDER BY sort_order`).all();
  res.json(categories);
});

catalogueRouter.get("/products", (req, res) => {
  const { search, category } = req.query as { search?: string; category?: string };
  let sql = `
    SELECT p.*, c.name AS category_name, c.slug AS category_slug
    FROM products p JOIN categories c ON c.id = p.category_id
    WHERE p.active = 1
  `;
  const params: any[] = [];
  if (search && search.trim()) {
    sql += ` AND (p.name LIKE ? OR p.generic_name LIKE ?)`;
    const like = `%${search.trim()}%`;
    params.push(like, like);
  }
  if (category && category.trim()) {
    sql += ` AND c.slug = ?`;
    params.push(category.trim());
  }
  sql += ` ORDER BY p.name`;
  const products = db.prepare(sql).all(...params);
  res.json(products);
});

catalogueRouter.get("/products/:id", (req, res) => {
  const product = db
    .prepare(
      `SELECT p.*, c.name AS category_name, c.slug AS category_slug
       FROM products p JOIN categories c ON c.id = p.category_id
       WHERE p.id = ? AND p.active = 1`
    )
    .get(req.params.id);
  if (!product) return res.status(404).json({ error: "Product not found" });
  res.json(product);
});

catalogueRouter.get("/delivery-zones", (req, res) => {
  const zones = db.prepare(`SELECT * FROM delivery_zones WHERE active = 1 ORDER BY sort_order`).all();
  res.json(zones);
});
