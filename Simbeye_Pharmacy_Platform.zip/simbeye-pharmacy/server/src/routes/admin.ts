import { Router } from "express";
import { db } from "../db";
import { hashPassword, makeToken, requireStaff, logNotification } from "../helpers";

export const adminRouter = Router();

// ---------------- Auth ----------------
adminRouter.post("/login", (req, res) => {
  const { email, password } = req.body || {};
  if (!email || !password) return res.status(400).json({ error: "Email and password required." });
  const staff = db.prepare(`SELECT * FROM staff WHERE email = ? AND active = 1`).get(email) as any;
  if (!staff || staff.password_hash !== hashPassword(password)) {
    return res.status(401).json({ error: "Invalid email or password." });
  }
  const token = makeToken();
  db.prepare(`INSERT INTO sessions (token, staff_id) VALUES (?, ?)`).run(token, staff.id);
  res.json({ token, staff: { id: staff.id, name: staff.name, role: staff.role, email: staff.email } });
});

adminRouter.post("/logout", requireStaff, (req: any, res) => {
  const token = req.headers["authorization"]?.replace("Bearer ", "");
  db.prepare(`DELETE FROM sessions WHERE token = ?`).run(token);
  res.json({ ok: true });
});

adminRouter.get("/me", requireStaff, (req: any, res) => {
  res.json(req.staff);
});

// ---------------- Dashboard overview ----------------
adminRouter.get("/overview", requireStaff, (req, res) => {
  const today = new Date().toISOString().slice(0, 10);
  const ordersToday = db
    .prepare(`SELECT COUNT(*) AS n FROM orders WHERE date(created_at) = ?`)
    .get(today) as any;
  const salesToday = db
    .prepare(`SELECT COALESCE(SUM(total),0) AS s FROM orders WHERE date(created_at) = ? AND payment_status != 'failed'`)
    .get(today) as any;
  const pending = db
    .prepare(`SELECT COUNT(*) AS n FROM orders WHERE order_status IN ('received','pharmacist_review','confirmed','preparing')`)
    .get() as any;
  const outForDelivery = db
    .prepare(`SELECT COUNT(*) AS n FROM orders WHERE order_status = 'out_for_delivery'`)
    .get() as any;
  const readyForCollection = db
    .prepare(`SELECT COUNT(*) AS n FROM orders WHERE order_status = 'ready_for_collection'`)
    .get() as any;
  const lowStock = db
    .prepare(`SELECT COUNT(*) AS n FROM products WHERE active = 1 AND stock_qty <= reorder_level`)
    .get() as any;
  const expiring = db
    .prepare(`SELECT COUNT(*) AS n FROM product_batches WHERE date(expiry_date) <= date('now', '+90 days')`)
    .get() as any;
  const pendingRx = db.prepare(`SELECT COUNT(*) AS n FROM prescriptions WHERE status = 'pending'`).get() as any;

  res.json({
    ordersToday: ordersToday.n,
    salesToday: salesToday.s,
    pendingOrders: pending.n,
    outForDelivery: outForDelivery.n,
    readyForCollection: readyForCollection.n,
    lowStockCount: lowStock.n,
    expiringCount: expiring.n,
    pendingPrescriptions: pendingRx.n,
  });
});

adminRouter.get("/low-stock", requireStaff, (req, res) => {
  const rows = db
    .prepare(`SELECT id, name, stock_qty, reorder_level FROM products WHERE active = 1 AND stock_qty <= reorder_level ORDER BY stock_qty ASC`)
    .all();
  res.json(rows);
});

adminRouter.get("/expiring", requireStaff, (req, res) => {
  const rows = db
    .prepare(
      `SELECT b.id, b.batch_number, b.expiry_date, b.quantity, p.name AS product_name
       FROM product_batches b JOIN products p ON p.id = b.product_id
       WHERE date(b.expiry_date) <= date('now', '+90 days')
       ORDER BY b.expiry_date ASC`
    )
    .all();
  res.json(rows);
});

// ---------------- Products ----------------
adminRouter.get("/products", requireStaff, (req, res) => {
  const rows = db
    .prepare(
      `SELECT p.*, c.name AS category_name FROM products p JOIN categories c ON c.id = p.category_id ORDER BY p.name`
    )
    .all();
  res.json(rows);
});

adminRouter.get("/categories", requireStaff, (req, res) => {
  res.json(db.prepare(`SELECT * FROM categories ORDER BY sort_order`).all());
});

adminRouter.post("/products", requireStaff, (req: any, res) => {
  if (!["super_admin", "inventory_manager"].includes(req.staff.role)) {
    return res.status(403).json({ error: "Not permitted to manage products." });
  }
  const p = req.body || {};
  if (!p.name || !p.categoryId || p.price == null) {
    return res.status(400).json({ error: "Name, category and price are required." });
  }
  const info = db
    .prepare(
      `INSERT INTO products (name, generic_name, category_id, strength, dosage_form, pack_size, price, purchase_price, stock_qty, reorder_level, requires_prescription, image_color, description, active)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)`
    )
    .run(
      p.name,
      p.genericName || null,
      p.categoryId,
      p.strength || null,
      p.dosageForm || null,
      p.packSize || null,
      p.price,
      p.purchasePrice || null,
      p.stockQty || 0,
      p.reorderLevel || 10,
      p.requiresPrescription ? 1 : 0,
      p.imageColor || "#0F2C59",
      p.description || null
    );
  res.status(201).json({ id: info.lastInsertRowid });
});

adminRouter.put("/products/:id", requireStaff, (req: any, res) => {
  if (!["super_admin", "inventory_manager"].includes(req.staff.role)) {
    return res.status(403).json({ error: "Not permitted to manage products." });
  }
  const p = req.body || {};
  const existing = db.prepare(`SELECT * FROM products WHERE id = ?`).get(req.params.id) as any;
  if (!existing) return res.status(404).json({ error: "Product not found." });
  db.prepare(
    `UPDATE products SET name=?, generic_name=?, category_id=?, strength=?, dosage_form=?, pack_size=?, price=?, purchase_price=?, stock_qty=?, reorder_level=?, requires_prescription=?, image_color=?, description=?, active=?
     WHERE id = ?`
  ).run(
    p.name ?? existing.name,
    p.genericName ?? existing.generic_name,
    p.categoryId ?? existing.category_id,
    p.strength ?? existing.strength,
    p.dosageForm ?? existing.dosage_form,
    p.packSize ?? existing.pack_size,
    p.price ?? existing.price,
    p.purchasePrice ?? existing.purchase_price,
    p.stockQty ?? existing.stock_qty,
    p.reorderLevel ?? existing.reorder_level,
    p.requiresPrescription != null ? (p.requiresPrescription ? 1 : 0) : existing.requires_prescription,
    p.imageColor ?? existing.image_color,
    p.description ?? existing.description,
    p.active != null ? (p.active ? 1 : 0) : existing.active,
    req.params.id
  );
  res.json({ ok: true });
});

// ---------------- Delivery zones (admin-editable, no code changes) ----------------
adminRouter.get("/delivery-zones", requireStaff, (req, res) => {
  res.json(db.prepare(`SELECT * FROM delivery_zones ORDER BY sort_order`).all());
});

adminRouter.post("/delivery-zones", requireStaff, (req: any, res) => {
  if (!["super_admin"].includes(req.staff.role)) return res.status(403).json({ error: "Not permitted." });
  const z = req.body || {};
  const info = db
    .prepare(`INSERT INTO delivery_zones (name, description, fee, is_contact_only, active, sort_order) VALUES (?, ?, ?, ?, ?, ?)`)
    .run(z.name, z.description || null, z.fee || 0, z.isContactOnly ? 1 : 0, z.active !== false ? 1 : 0, z.sortOrder || 99);
  res.status(201).json({ id: info.lastInsertRowid });
});

adminRouter.put("/delivery-zones/:id", requireStaff, (req: any, res) => {
  if (!["super_admin"].includes(req.staff.role)) return res.status(403).json({ error: "Not permitted." });
  const existing = db.prepare(`SELECT * FROM delivery_zones WHERE id = ?`).get(req.params.id) as any;
  if (!existing) return res.status(404).json({ error: "Zone not found." });
  const z = req.body || {};
  db.prepare(
    `UPDATE delivery_zones SET name=?, description=?, fee=?, is_contact_only=?, active=?, sort_order=? WHERE id=?`
  ).run(
    z.name ?? existing.name,
    z.description ?? existing.description,
    z.fee ?? existing.fee,
    z.isContactOnly != null ? (z.isContactOnly ? 1 : 0) : existing.is_contact_only,
    z.active != null ? (z.active ? 1 : 0) : existing.active,
    z.sortOrder ?? existing.sort_order,
    req.params.id
  );
  res.json({ ok: true });
});

// ---------------- Orders ----------------
adminRouter.get("/orders", requireStaff, (req, res) => {
  const { status } = req.query as { status?: string };
  let sql = `SELECT * FROM orders`;
  const params: any[] = [];
  if (status) {
    sql += ` WHERE order_status = ?`;
    params.push(status);
  }
  sql += ` ORDER BY created_at DESC LIMIT 200`;
  res.json(db.prepare(sql).all(...params));
});

adminRouter.get("/orders/:id", requireStaff, (req, res) => {
  const order = db.prepare(`SELECT * FROM orders WHERE id = ?`).get(req.params.id);
  if (!order) return res.status(404).json({ error: "Order not found." });
  const items = db.prepare(`SELECT * FROM order_items WHERE order_id = ?`).all(req.params.id);
  res.json({ ...order, items });
});

const VALID_TRANSITIONS: Record<string, string[]> = {
  received: ["pharmacist_review", "confirmed", "cancelled"],
  pharmacist_review: ["confirmed", "cancelled"],
  confirmed: ["preparing", "cancelled"],
  preparing: ["out_for_delivery", "ready_for_collection", "cancelled"],
  out_for_delivery: ["delivered", "cancelled"],
  ready_for_collection: ["collected", "cancelled"],
  delivered: [],
  collected: [],
  cancelled: [],
};

adminRouter.put("/orders/:id/status", requireStaff, (req: any, res) => {
  const order = db.prepare(`SELECT * FROM orders WHERE id = ?`).get(req.params.id) as any;
  if (!order) return res.status(404).json({ error: "Order not found." });
  const { status } = req.body || {};
  const allowed = VALID_TRANSITIONS[order.order_status] || [];
  if (!allowed.includes(status)) {
    return res.status(400).json({ error: `Cannot move order from ${order.order_status} to ${status}.` });
  }
  db.prepare(`UPDATE orders SET order_status = ?, updated_at = datetime('now') WHERE id = ?`).run(status, order.id);
  const messages: Record<string, string> = {
    confirmed: `Your order ${order.order_number} has been confirmed and is being prepared.`,
    preparing: `Your order ${order.order_number} is being prepared.`,
    out_for_delivery: `Your order ${order.order_number} is out for delivery.`,
    ready_for_collection: `Your order ${order.order_number} is ready for collection at the pharmacy.`,
    delivered: `Your order ${order.order_number} has been delivered. Thank you for choosing Simbeye Pharmacy!`,
    collected: `Your order ${order.order_number} has been collected. Thank you for choosing Simbeye Pharmacy!`,
    cancelled: `Your order ${order.order_number} has been cancelled. Contact us if you have questions.`,
  };
  if (messages[status]) logNotification(order.id, "whatsapp", messages[status]);
  res.json({ ok: true });
});

adminRouter.put("/orders/:id/payment-status", requireStaff, (req: any, res) => {
  if (!["super_admin", "cashier"].includes(req.staff.role)) return res.status(403).json({ error: "Not permitted." });
  const { paymentStatus } = req.body || {};
  if (!["pending", "paid", "failed"].includes(paymentStatus)) {
    return res.status(400).json({ error: "Invalid payment status." });
  }
  db.prepare(`UPDATE orders SET payment_status = ?, updated_at = datetime('now') WHERE id = ?`).run(paymentStatus, req.params.id);
  res.json({ ok: true });
});

// ---------------- Prescriptions review queue ----------------
adminRouter.get("/prescriptions", requireStaff, (req, res) => {
  const { status } = req.query as { status?: string };
  let sql = `SELECT * FROM prescriptions`;
  const params: any[] = [];
  if (status) {
    sql += ` WHERE status = ?`;
    params.push(status);
  }
  sql += ` ORDER BY created_at DESC`;
  res.json(db.prepare(sql).all(...params));
});

adminRouter.put("/prescriptions/:id/review", requireStaff, (req: any, res) => {
  if (!["super_admin", "pharmacist"].includes(req.staff.role)) {
    return res.status(403).json({ error: "Only pharmacists can review prescriptions." });
  }
  const { status, notes } = req.body || {};
  if (!["approved", "rejected"].includes(status)) return res.status(400).json({ error: "Invalid status." });
  const rx = db.prepare(`SELECT * FROM prescriptions WHERE id = ?`).get(req.params.id) as any;
  if (!rx) return res.status(404).json({ error: "Prescription not found." });
  db.prepare(`UPDATE prescriptions SET status = ?, pharmacist_notes = ?, reviewed_at = datetime('now') WHERE id = ?`).run(
    status,
    notes || null,
    req.params.id
  );
  if (rx.order_id) {
    const nextStatus = status === "approved" ? "confirmed" : "cancelled";
    const order = db.prepare(`SELECT * FROM orders WHERE id = ?`).get(rx.order_id) as any;
    if (order) {
      db.prepare(`UPDATE orders SET order_status = ?, updated_at = datetime('now') WHERE id = ?`).run(nextStatus, order.id);
      logNotification(
        order.id,
        "whatsapp",
        status === "approved"
          ? `Your prescription for order ${order.order_number} was approved. Your order is now being prepared.`
          : `Your prescription for order ${order.order_number} could not be approved. Please contact the pharmacy.`
      );
    }
  }
  res.json({ ok: true });
});

// ---------------- Staff ----------------
adminRouter.get("/staff", requireStaff, (req: any, res) => {
  if (req.staff.role !== "super_admin") return res.status(403).json({ error: "Not permitted." });
  res.json(db.prepare(`SELECT id, name, email, role, active FROM staff`).all());
});
