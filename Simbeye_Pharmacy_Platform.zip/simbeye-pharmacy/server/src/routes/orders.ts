import { Router } from "express";
import { db } from "../db";
import { nextOrderNumber, logNotification } from "../helpers";

export const ordersRouter = Router();

const STATUS_MESSAGES: Record<string, string> = {
  received: "Simbeye Pharmacy has received your order {ORDER}. We'll confirm shortly.",
  pharmacist_review: "Your order {ORDER} includes a prescription item and is being reviewed by our pharmacist.",
  confirmed: "Your order {ORDER} has been confirmed and is being prepared.",
  preparing: "Your order {ORDER} is being prepared.",
  out_for_delivery: "Your order {ORDER} is out for delivery.",
  ready_for_collection: "Your order {ORDER} is ready for collection at the pharmacy.",
  delivered: "Your order {ORDER} has been delivered. Thank you for choosing Simbeye Pharmacy!",
  collected: "Your order {ORDER} has been collected. Thank you for choosing Simbeye Pharmacy!",
  cancelled: "Your order {ORDER} has been cancelled.",
};

// ---------------------------------------------------------------------
// POST /api/orders — create an order.
// Prices and the delivery fee are ALWAYS recomputed server-side from the
// database, never trusted from the client, so nothing in the browser can
// manipulate a total. Stock is decremented in the same transaction as
// order creation so two customers can't both "buy" the last unit.
// ---------------------------------------------------------------------
ordersRouter.post("/orders", (req, res) => {
  const {
    customerName,
    customerPhone,
    items, // [{ productId, qty }]
    fulfillmentType, // 'delivery' | 'collection'
    deliveryZoneId,
    addressText,
    landmark,
    deliveryInstructions,
    paymentMethod, // 'mobile_money' | 'card' | 'cash'
    notes,
  } = req.body || {};

  if (!customerName || !customerPhone) {
    return res.status(400).json({ error: "Name and phone number are required." });
  }
  if (!Array.isArray(items) || items.length === 0) {
    return res.status(400).json({ error: "Cart is empty." });
  }
  if (!["delivery", "collection"].includes(fulfillmentType)) {
    return res.status(400).json({ error: "Invalid fulfillment type." });
  }
  if (!["mobile_money", "card", "cash"].includes(paymentMethod)) {
    return res.status(400).json({ error: "Invalid payment method." });
  }

  try {
    const result = db.transaction(() => {
      // Look up every product fresh from the DB (authoritative price + stock)
      const getProduct = db.prepare(`SELECT * FROM products WHERE id = ? AND active = 1`);
      let subtotal = 0;
      let hasPrescriptionItems = 0;
      const lineItems: any[] = [];

      for (const item of items) {
        const product = getProduct.get(item.productId) as any;
        if (!product) throw new Error(`Product ${item.productId} not found.`);
        const qty = Math.max(1, Number(item.qty) || 1);
        if (product.stock_qty < qty) {
          throw new Error(`${product.name} only has ${product.stock_qty} in stock.`);
        }
        const lineTotal = product.price * qty;
        subtotal += lineTotal;
        if (product.requires_prescription) hasPrescriptionItems = 1;
        lineItems.push({ product, qty, lineTotal });
      }

      // Delivery fee
      let deliveryFee = 0;
      let zone: any = null;
      if (fulfillmentType === "delivery") {
        if (!deliveryZoneId) throw new Error("Please select a delivery zone.");
        zone = db.prepare(`SELECT * FROM delivery_zones WHERE id = ? AND active = 1`).get(deliveryZoneId);
        if (!zone) throw new Error("Invalid delivery zone.");
        if (zone.is_contact_only) {
          throw new Error("This location is outside our delivery area — please contact the pharmacy directly.");
        }
        deliveryFee = zone.fee;
      }

      const total = subtotal + deliveryFee;

      // Upsert customer by phone
      let customer = db.prepare(`SELECT * FROM customers WHERE phone = ?`).get(customerPhone) as any;
      if (!customer) {
        const info = db.prepare(`INSERT INTO customers (name, phone) VALUES (?, ?)`).run(customerName, customerPhone);
        customer = { id: info.lastInsertRowid };
      }

      const orderNumber = nextOrderNumber();
      const initialStatus = hasPrescriptionItems ? "pharmacist_review" : "received";
      // Cash is always pending until collected/delivered. Mobile money / card
      // start pending too — the client calls the payment-simulation endpoint
      // right after, mirroring an async gateway callback in production.
      const paymentStatus = "pending";

      const orderInfo = db
        .prepare(
          `INSERT INTO orders
            (order_number, customer_id, customer_name, customer_phone, fulfillment_type, delivery_zone_id,
             delivery_fee, address_text, landmark, delivery_instructions, subtotal, total, payment_method,
             payment_status, order_status, has_prescription_items, notes)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
        )
        .run(
          orderNumber,
          customer.id,
          customerName,
          customerPhone,
          fulfillmentType,
          zone ? zone.id : null,
          deliveryFee,
          addressText || null,
          landmark || null,
          deliveryInstructions || null,
          subtotal,
          total,
          paymentMethod,
          paymentStatus,
          initialStatus,
          hasPrescriptionItems,
          notes || null
        );
      const orderId = orderInfo.lastInsertRowid as number;

      const insItem = db.prepare(
        `INSERT INTO order_items (order_id, product_id, product_name, requires_prescription, qty, unit_price, line_total)
         VALUES (?, ?, ?, ?, ?, ?, ?)`
      );
      const decStock = db.prepare(`UPDATE products SET stock_qty = stock_qty - ? WHERE id = ?`);
      for (const li of lineItems) {
        insItem.run(orderId, li.product.id, li.product.name, li.product.requires_prescription, li.qty, li.product.price, li.lineTotal);
        decStock.run(li.qty, li.product.id);
      }

      logNotification(
        orderId,
        "whatsapp",
        STATUS_MESSAGES[initialStatus].replace("{ORDER}", orderNumber)
      );

      return { orderId, orderNumber, subtotal, deliveryFee, total, paymentStatus, orderStatus: initialStatus, hasPrescriptionItems: !!hasPrescriptionItems };
    })();

    res.status(201).json(result);
  } catch (err: any) {
    res.status(400).json({ error: err.message || "Could not place order." });
  }
});

// ---------------------------------------------------------------------
// POST /api/orders/:orderNumber/simulate-payment
// STUB ONLY. Real mobile money / card payments must go through a
// licensed Tanzania-compatible payment gateway (e.g. Azampay, Selcom,
// Flutterwave, DPO Pay). This endpoint exists so the MVP checkout flow
// can be demoed end to end without live payment credentials. Replace
// with a real gateway webhook handler before launch.
// ---------------------------------------------------------------------
ordersRouter.post("/orders/:orderNumber/simulate-payment", (req, res) => {
  const order = db.prepare(`SELECT * FROM orders WHERE order_number = ?`).get(req.params.orderNumber) as any;
  if (!order) return res.status(404).json({ error: "Order not found." });
  if (order.payment_method === "cash") {
    return res.status(400).json({ error: "Cash orders are paid on delivery/collection, not online." });
  }
  db.prepare(`UPDATE orders SET payment_status = 'paid', updated_at = datetime('now') WHERE id = ?`).run(order.id);
  logNotification(order.id, "sms", `Payment received for order ${order.order_number}. Thank you!`);
  res.json({ ok: true, paymentStatus: "paid" });
});

// ---------------------------------------------------------------------
// GET /api/orders/:orderNumber?phone=XXXX — public order tracking.
// Requires the phone number used at checkout, so order numbers alone
// (which are sequential and guessable) can't be used to snoop on orders.
// ---------------------------------------------------------------------
ordersRouter.get("/orders/:orderNumber", (req, res) => {
  const { phone } = req.query as { phone?: string };
  const order = db.prepare(`SELECT * FROM orders WHERE order_number = ?`).get(req.params.orderNumber) as any;
  if (!order) return res.status(404).json({ error: "Order not found." });
  if (!phone || order.customer_phone !== phone) {
    return res.status(403).json({ error: "Enter the phone number used for this order to track it." });
  }
  const items = db.prepare(`SELECT * FROM order_items WHERE order_id = ?`).all(order.id);
  const zone = order.delivery_zone_id
    ? db.prepare(`SELECT * FROM delivery_zones WHERE id = ?`).get(order.delivery_zone_id)
    : null;
  res.json({ ...order, items, zone });
});
