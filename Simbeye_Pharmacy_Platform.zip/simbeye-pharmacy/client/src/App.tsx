import { Routes, Route } from "react-router-dom";
import { Layout } from "./components/Layout";
import { Home } from "./pages/Home";
import { Shop } from "./pages/Shop";
import { ProductDetail } from "./pages/ProductDetail";
import { Cart } from "./pages/Cart";
import { Checkout } from "./pages/Checkout";
import { OrderConfirmation } from "./pages/OrderConfirmation";
import { TrackOrder } from "./pages/TrackOrder";
import { AdminLogin } from "./pages/admin/AdminLogin";
import { AdminLayout } from "./pages/admin/AdminLayout";
import { AdminDashboard } from "./pages/admin/AdminDashboard";
import { AdminProducts } from "./pages/admin/AdminProducts";
import { AdminDeliveryZones } from "./pages/admin/AdminDeliveryZones";
import { AdminOrders } from "./pages/admin/AdminOrders";
import { AdminPrescriptions } from "./pages/admin/AdminPrescriptions";

function App() {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route path="/" element={<Home />} />
        <Route path="/shop" element={<Shop />} />
        <Route path="/product/:id" element={<ProductDetail />} />
        <Route path="/cart" element={<Cart />} />
        <Route path="/checkout" element={<Checkout />} />
        <Route path="/order/:orderNumber/confirmation" element={<OrderConfirmation />} />
        <Route path="/track" element={<TrackOrder />} />
      </Route>

      <Route path="/admin/login" element={<AdminLogin />} />
      <Route path="/admin" element={<AdminLayout />}>
        <Route index element={<AdminDashboard />} />
        <Route path="products" element={<AdminProducts />} />
        <Route path="delivery-zones" element={<AdminDeliveryZones />} />
        <Route path="orders" element={<AdminOrders />} />
        <Route path="prescriptions" element={<AdminPrescriptions />} />
      </Route>
    </Routes>
  );
}

export default App;
