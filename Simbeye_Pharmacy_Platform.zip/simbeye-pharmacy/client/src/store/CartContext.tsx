import { createContext, useContext, useEffect, useMemo, useState } from "react";
import type { ReactNode } from "react";
import type { CartLine, Product } from "../lib/types";

interface CartContextValue {
  lines: CartLine[];
  addItem: (product: Product, qty?: number) => void;
  updateQty: (productId: number, qty: number) => void;
  removeItem: (productId: number) => void;
  clear: () => void;
  subtotal: number;
  itemCount: number;
  hasPrescriptionItems: boolean;
}

const CartContext = createContext<CartContextValue | null>(null);
const STORAGE_KEY = "simbeye_cart_v1";

export function CartProvider({ children }: { children: ReactNode }) {
  const [lines, setLines] = useState<CartLine[]>(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      return raw ? (JSON.parse(raw) as CartLine[]) : [];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(lines));
  }, [lines]);

  const addItem = (product: Product, qty = 1) => {
    setLines((prev) => {
      const existing = prev.find((l) => l.product.id === product.id);
      if (existing) {
        const nextQty = Math.min(existing.qty + qty, product.stock_qty);
        return prev.map((l) => (l.product.id === product.id ? { ...l, qty: nextQty } : l));
      }
      return [...prev, { product, qty: Math.min(qty, product.stock_qty) }];
    });
  };

  const updateQty = (productId: number, qty: number) => {
    setLines((prev) =>
      prev
        .map((l) => (l.product.id === productId ? { ...l, qty: Math.max(0, Math.min(qty, l.product.stock_qty)) } : l))
        .filter((l) => l.qty > 0)
    );
  };

  const removeItem = (productId: number) => setLines((prev) => prev.filter((l) => l.product.id !== productId));
  const clear = () => setLines([]);

  const subtotal = useMemo(() => lines.reduce((sum, l) => sum + l.product.price * l.qty, 0), [lines]);
  const itemCount = useMemo(() => lines.reduce((sum, l) => sum + l.qty, 0), [lines]);
  const hasPrescriptionItems = useMemo(() => lines.some((l) => l.product.requires_prescription), [lines]);

  return (
    <CartContext.Provider value={{ lines, addItem, updateQty, removeItem, clear, subtotal, itemCount, hasPrescriptionItems }}>
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error("useCart must be used within CartProvider");
  return ctx;
}
