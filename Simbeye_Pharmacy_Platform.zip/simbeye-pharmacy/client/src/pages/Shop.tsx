import { useEffect, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { api } from "../lib/api";
import type { Category, Product } from "../lib/types";
import { ProductCard } from "../components/ProductCard";

export function Shop() {
  const [searchParams, setSearchParams] = useSearchParams();
  const [categories, setCategories] = useState<Category[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const search = searchParams.get("search") || "";
  const category = searchParams.get("category") || "";
  const rxOnly = searchParams.get("rx") === "1";

  useEffect(() => {
    api.categories().then(setCategories).catch(() => {});
  }, []);

  useEffect(() => {
    setLoading(true);
    api
      .products({ search, category })
      .then((data: Product[]) => setProducts(rxOnly ? data.filter((p) => p.requires_prescription) : data))
      .catch(() => setProducts([]))
      .finally(() => setLoading(false));
  }, [search, category, rxOnly]);

  const updateParam = (key: string, value: string) => {
    const next = new URLSearchParams(searchParams);
    if (value) next.set(key, value);
    else next.delete(key);
    if (key !== "search") next.delete("rx");
    setSearchParams(next);
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row gap-3 md:items-center md:justify-between mb-6">
        <h1 className="font-display font-bold text-2xl text-slate">
          {rxOnly ? "Prescription Medicines" : category ? categories.find((c) => c.slug === category)?.name || "Shop" : "Shop"}
        </h1>
        <input
          defaultValue={search}
          onChange={(e) => updateParam("search", e.target.value)}
          placeholder="🔎 Search medicines & products..."
          className="border border-slate-200 rounded-lg px-4 py-2 w-full md:w-80 outline-none focus:border-teal"
        />
      </div>

      <div className="flex gap-2 flex-wrap mb-6">
        <button
          onClick={() => updateParam("category", "")}
          className={`text-xs font-medium px-3 py-1.5 rounded-full border ${
            !category ? "bg-navy text-white border-navy" : "border-slate-200 text-slate-600 hover:border-navy"
          }`}
        >
          All categories
        </button>
        {categories.map((c) => (
          <button
            key={c.id}
            onClick={() => updateParam("category", c.slug)}
            className={`text-xs font-medium px-3 py-1.5 rounded-full border ${
              category === c.slug ? "bg-navy text-white border-navy" : "border-slate-200 text-slate-600 hover:border-navy"
            }`}
          >
            {c.icon} {c.name}
          </button>
        ))}
      </div>

      {loading ? (
        <p className="text-slate-500">Loading products…</p>
      ) : products.length === 0 ? (
        <div className="text-center py-16 text-slate-500">
          <p className="text-lg">No products found.</p>
          <p className="text-sm mt-1">Try a different search term, or ask us on WhatsApp — we may still have it.</p>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
          {products.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      )}
    </div>
  );
}
