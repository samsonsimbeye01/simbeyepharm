import { Link, useNavigate } from "react-router-dom";
import { useCart } from "../store/CartContext";
import { formatTZS } from "../lib/format";

export function Cart() {
  const { lines, updateQty, removeItem, subtotal, hasPrescriptionItems } = useCart();
  const navigate = useNavigate();

  if (lines.length === 0) {
    return (
      <div className="max-w-3xl mx-auto px-4 py-20 text-center">
        <div className="text-5xl mb-4">🛒</div>
        <h1 className="font-display font-bold text-xl text-slate">Your cart is empty</h1>
        <Link to="/shop" className="inline-block mt-4 bg-teal text-white px-5 py-2.5 rounded-lg font-semibold hover:bg-teal/90">
          Start shopping
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto px-4 py-8">
      <h1 className="font-display font-bold text-2xl text-slate mb-6">Your Cart</h1>

      {hasPrescriptionItems ? (
        <div className="mb-4 bg-amber-50 border border-amber-200 text-amber-800 text-sm rounded-lg p-3">
          🔒 Your cart includes prescription medicine(s). You'll upload a prescription at checkout for pharmacist review.
        </div>
      ) : null}

      <div className="bg-white rounded-xl border border-slate-100 divide-y">
        {lines.map((l) => (
          <div key={l.product.id} className="p-4 flex items-center gap-4">
            <div
              className="w-12 h-12 rounded-lg flex items-center justify-center text-white font-bold text-sm flex-shrink-0"
              style={{ backgroundColor: l.product.image_color }}
            >
              {l.product.name.slice(0, 2).toUpperCase()}
            </div>
            <div className="flex-1 min-w-0">
              <p className="font-medium text-slate truncate">{l.product.name}</p>
              <p className="text-xs text-slate-500">{formatTZS(l.product.price)} each</p>
            </div>
            <div className="flex items-center border border-slate-200 rounded-lg">
              <button onClick={() => updateQty(l.product.id, l.qty - 1)} className="px-2.5 py-1 text-slate-500">
                −
              </button>
              <span className="px-2 text-sm font-medium">{l.qty}</span>
              <button
                onClick={() => updateQty(l.product.id, l.qty + 1)}
                disabled={l.qty >= l.product.stock_qty}
                className="px-2.5 py-1 text-slate-500 disabled:opacity-30"
              >
                +
              </button>
            </div>
            <p className="font-semibold text-navy w-24 text-right">{formatTZS(l.product.price * l.qty)}</p>
            <button onClick={() => removeItem(l.product.id)} className="text-slate-400 hover:text-red text-sm">
              ✕
            </button>
          </div>
        ))}
      </div>

      <div className="mt-6 bg-white rounded-xl border border-slate-100 p-5">
        <div className="flex justify-between text-slate-600 mb-2">
          <span>Subtotal</span>
          <span className="font-semibold text-slate">{formatTZS(subtotal)}</span>
        </div>
        <p className="text-xs text-slate-400 mb-4">Delivery fee is calculated at checkout based on your location.</p>
        <button
          onClick={() => navigate("/checkout")}
          className="w-full bg-teal text-white font-semibold py-3 rounded-lg hover:bg-teal/90"
        >
          Proceed to Checkout
        </button>
      </div>
    </div>
  );
}
