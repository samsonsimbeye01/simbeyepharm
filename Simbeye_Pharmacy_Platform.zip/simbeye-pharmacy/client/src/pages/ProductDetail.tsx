import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { api } from "../lib/api";
import type { Product } from "../lib/types";
import { formatTZS } from "../lib/format";
import { StockBadge } from "../components/StockBadge";
import { useCart } from "../store/CartContext";

export function ProductDetail() {
  const { id } = useParams();
  const [product, setProduct] = useState<Product | null>(null);
  const [qty, setQty] = useState(1);
  const [added, setAdded] = useState(false);
  const { addItem } = useCart();

  useEffect(() => {
    if (!id) return;
    api.product(id).then(setProduct).catch(() => setProduct(null));
  }, [id]);

  if (!product) {
    return <div className="max-w-4xl mx-auto px-4 py-16 text-center text-slate-500">Loading…</div>;
  }

  const initials = product.name.split(" ").slice(0, 2).map((w) => w[0]).join("").toUpperCase();

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <Link to="/shop" className="text-sm text-teal hover:underline">
        ← Back to shop
      </Link>
      <div className="mt-4 grid md:grid-cols-2 gap-8">
        <div
          className="rounded-xl h-64 flex items-center justify-center text-white font-display font-bold text-5xl"
          style={{ backgroundColor: product.image_color }}
        >
          {initials}
        </div>
        <div>
          {product.requires_prescription ? (
            <span className="text-xs font-semibold text-navy bg-navy/10 px-2 py-1 rounded-full">
              🔒 Prescription required
            </span>
          ) : null}
          <h1 className="font-display font-bold text-2xl text-slate mt-2">{product.name}</h1>
          {product.generic_name ? <p className="text-slate-500">{product.generic_name}</p> : null}
          <p className="text-sm text-slate-500 mt-1">
            {product.dosage_form} &middot; {product.category_name}
          </p>
          <div className="mt-4">
            <StockBadge stock={product.stock_qty} reorderLevel={product.reorder_level} />
          </div>
          <p className="font-display font-extrabold text-3xl text-navy mt-4">{formatTZS(product.price)}</p>

          {product.requires_prescription ? (
            <div className="mt-4 bg-amber-50 border border-amber-200 text-amber-800 text-sm rounded-lg p-3">
              This is a prescription medicine. You'll be asked to upload a valid prescription at checkout, and our
              pharmacist will review your order before it's dispensed.
            </div>
          ) : null}

          <div className="mt-6 flex items-center gap-3">
            <div className="flex items-center border border-slate-200 rounded-lg">
              <button
                onClick={() => setQty((q) => Math.max(1, q - 1))}
                className="px-3 py-2 text-slate-500 hover:text-navy"
              >
                −
              </button>
              <span className="px-3 font-medium">{qty}</span>
              <button
                onClick={() => setQty((q) => Math.min(product.stock_qty, q + 1))}
                className="px-3 py-2 text-slate-500 hover:text-navy"
              >
                +
              </button>
            </div>
            <button
              disabled={product.stock_qty <= 0}
              onClick={() => {
                addItem(product, qty);
                setAdded(true);
                setTimeout(() => setAdded(false), 1500);
              }}
              className="flex-1 bg-teal text-white font-semibold py-2.5 rounded-lg hover:bg-teal/90 disabled:bg-slate-200 disabled:text-slate-400"
            >
              {product.stock_qty <= 0 ? "Out of stock" : added ? "Added ✓" : "Add to cart"}
            </button>
          </div>

          {product.description ? <p className="text-sm text-slate-600 mt-6">{product.description}</p> : null}
        </div>
      </div>
    </div>
  );
}
