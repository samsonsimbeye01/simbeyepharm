import { useEffect, useState } from "react";
import { Link, useParams, useSearchParams } from "react-router-dom";
import { api } from "../lib/api";
import { formatTZS } from "../lib/format";

export function OrderConfirmation() {
  const { orderNumber } = useParams();
  const [searchParams] = useSearchParams();
  const phone = searchParams.get("phone") || "";
  const [order, setOrder] = useState<any>(null);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!orderNumber || !phone) return;
    api
      .trackOrder(orderNumber, phone)
      .then(setOrder)
      .catch((e) => setError(e.message));
  }, [orderNumber, phone]);

  if (error) return <div className="max-w-xl mx-auto px-4 py-16 text-center text-red">{error}</div>;
  if (!order) return <div className="max-w-xl mx-auto px-4 py-16 text-center text-slate-500">Loading…</div>;

  return (
    <div className="max-w-xl mx-auto px-4 py-12 text-center">
      <div className="text-5xl mb-4">✅</div>
      <h1 className="font-display font-bold text-2xl text-slate">Order placed!</h1>
      <p className="text-slate-500 mt-1">
        Order <span className="font-semibold text-navy">{order.order_number}</span>
      </p>

      <div className="bg-white border border-slate-100 rounded-xl p-5 mt-6 text-left">
        {order.has_prescription_items ? (
          <div className="bg-amber-50 border border-amber-200 text-amber-800 text-sm rounded-lg p-3 mb-4">
            Your order includes a prescription item — our pharmacist will review it before it's prepared. We'll
            notify you as soon as it's approved.
          </div>
        ) : null}
        <div className="space-y-1.5 text-sm">
          <div className="flex justify-between text-slate-600">
            <span>Medicines & products</span>
            <span>{formatTZS(order.subtotal)}</span>
          </div>
          <div className="flex justify-between text-slate-600">
            <span>Delivery</span>
            <span>{order.fulfillment_type === "collection" ? "Free (collection)" : formatTZS(order.delivery_fee)}</span>
          </div>
          <div className="flex justify-between font-display font-bold text-navy text-base pt-2 border-t border-slate-100 mt-2">
            <span>Total</span>
            <span>{formatTZS(order.total)}</span>
          </div>
        </div>
        <div className="mt-4 pt-4 border-t border-slate-100 text-sm text-slate-600 space-y-1">
          <p>
            Payment: <span className="font-medium capitalize">{order.payment_method.replace("_", " ")}</span> —{" "}
            <span className={order.payment_status === "paid" ? "text-teal font-medium" : "text-amber-600 font-medium"}>
              {order.payment_status === "paid" ? "Paid" : "Pending"}
            </span>
          </p>
          <p>
            {order.fulfillment_type === "delivery" ? "Delivering to" : "Collecting from"}:{" "}
            <span className="font-medium">
              {order.fulfillment_type === "delivery" ? order.address_text : "Simbeye Pharmacy — main branch"}
            </span>
          </p>
        </div>
      </div>

      <div className="flex gap-3 mt-6">
        <Link
          to={`/track?order=${order.order_number}&phone=${encodeURIComponent(phone)}`}
          className="flex-1 bg-teal text-white font-semibold py-2.5 rounded-lg hover:bg-teal/90"
        >
          Track this order
        </Link>
        <a
          href="https://wa.me/255700000000"
          target="_blank"
          rel="noreferrer"
          className="flex-1 bg-[#25D366] text-white font-semibold py-2.5 rounded-lg hover:opacity-90"
        >
          Need help? WhatsApp us
        </a>
      </div>
      <Link to="/shop" className="inline-block mt-4 text-sm text-slate-500 hover:text-teal">
        ← Continue shopping
      </Link>
    </div>
  );
}
