import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useCart } from "../store/CartContext";
import { api } from "../lib/api";
import type { DeliveryZone } from "../lib/types";
import { formatTZS } from "../lib/format";

type FulfillmentType = "delivery" | "collection";
type PaymentMethod = "mobile_money" | "card" | "cash";

export function Checkout() {
  const { lines, subtotal, hasPrescriptionItems, clear } = useCart();
  const navigate = useNavigate();

  const [zones, setZones] = useState<DeliveryZone[]>([]);
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [fulfillment, setFulfillment] = useState<FulfillmentType>("delivery");
  const [zoneId, setZoneId] = useState<number | null>(null);
  const [address, setAddress] = useState("");
  const [landmark, setLandmark] = useState("");
  const [instructions, setInstructions] = useState("");
  const [payment, setPayment] = useState<PaymentMethod>("mobile_money");
  const [prescriptionFile, setPrescriptionFile] = useState<File | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [processingLabel, setProcessingLabel] = useState("");
  const [error, setError] = useState("");

  useEffect(() => {
    api.deliveryZones().then((z: DeliveryZone[]) => {
      setZones(z);
      const firstOrderable = z.find((zone) => !zone.is_contact_only);
      if (firstOrderable) setZoneId(firstOrderable.id);
    });
  }, []);

  useEffect(() => {
    // Skip the empty-cart redirect while we're mid-checkout: placeOrder() clears
    // the cart right before navigating to the confirmation page, and without this
    // guard that clear() races with the confirmation navigate() and can bounce
    // the customer back to /shop instead of showing their just-placed order.
    if (lines.length === 0 && !submitting) navigate("/shop");
  }, [lines, navigate, submitting]);

  const selectedZone = zones.find((z) => z.id === zoneId) || null;
  const deliveryFee = fulfillment === "delivery" ? selectedZone?.fee ?? 0 : 0;
  const total = subtotal + deliveryFee;
  const outsideArea = fulfillment === "delivery" && selectedZone?.is_contact_only;

  const canSubmit =
    name.trim() &&
    /^0\d{9}$/.test(phone.trim()) &&
    (fulfillment === "collection" || (zoneId && !outsideArea && address.trim())) &&
    (!hasPrescriptionItems || prescriptionFile) &&
    !submitting;

  const placeOrder = async () => {
    setError("");
    setSubmitting(true);
    try {
      setProcessingLabel("Placing your order…");
      const order = await api.createOrder({
        customerName: name.trim(),
        customerPhone: phone.trim(),
        items: lines.map((l) => ({ productId: l.product.id, qty: l.qty })),
        fulfillmentType: fulfillment,
        deliveryZoneId: fulfillment === "delivery" ? zoneId : null,
        addressText: fulfillment === "delivery" ? address.trim() : null,
        landmark: fulfillment === "delivery" ? landmark.trim() : null,
        deliveryInstructions: fulfillment === "delivery" ? instructions.trim() : null,
        paymentMethod: payment,
      });

      if (hasPrescriptionItems && prescriptionFile) {
        setProcessingLabel("Uploading your prescription…");
        await api.uploadPrescription(prescriptionFile, phone.trim(), order.orderId);
      }

      if (payment !== "cash") {
        setProcessingLabel(payment === "mobile_money" ? "Confirming Mobile Money payment…" : "Confirming card payment…");
        await new Promise((r) => setTimeout(r, 1200)); // simulated gateway round-trip
        await api.simulatePayment(order.orderNumber);
      }

      clear();
      navigate(`/order/${order.orderNumber}/confirmation?phone=${encodeURIComponent(phone.trim())}`);
    } catch (e: any) {
      setError(e.message || "Something went wrong placing your order.");
      setSubmitting(false);
      setProcessingLabel("");
    }
  };

  return (
    <div className="max-w-3xl mx-auto px-4 py-8">
      <h1 className="font-display font-bold text-2xl text-slate mb-6">Checkout</h1>

      {/* Step 1 — Customer */}
      <section className="bg-white rounded-xl border border-slate-100 p-5 mb-4">
        <h2 className="font-semibold text-slate mb-3">1. Your details</h2>
        <div className="grid sm:grid-cols-2 gap-3">
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Full name"
            className="border border-slate-200 rounded-lg px-3 py-2.5 outline-none focus:border-teal"
          />
          <input
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            placeholder="Phone number e.g. 0712345678"
            className="border border-slate-200 rounded-lg px-3 py-2.5 outline-none focus:border-teal"
          />
        </div>
        <p className="text-xs text-slate-400 mt-2">No account needed — we'll use your phone number to send order updates.</p>
      </section>

      {/* Step 2 — Delivery / Collection */}
      <section className="bg-white rounded-xl border border-slate-100 p-5 mb-4">
        <h2 className="font-semibold text-slate mb-3">2. Delivery or collection</h2>
        <div className="flex gap-3 mb-4">
          <button
            onClick={() => setFulfillment("delivery")}
            className={`flex-1 border rounded-lg py-2.5 text-sm font-medium ${
              fulfillment === "delivery" ? "border-teal bg-teal/10 text-teal" : "border-slate-200 text-slate-600"
            }`}
          >
            🚚 Delivery
          </button>
          <button
            onClick={() => setFulfillment("collection")}
            className={`flex-1 border rounded-lg py-2.5 text-sm font-medium ${
              fulfillment === "collection" ? "border-teal bg-teal/10 text-teal" : "border-slate-200 text-slate-600"
            }`}
          >
            🏪 Collect at pharmacy
          </button>
        </div>

        {fulfillment === "delivery" ? (
          <div className="space-y-3">
            <div>
              <label className="text-xs font-medium text-slate-500">📍 Delivery zone</label>
              <select
                value={zoneId ?? ""}
                onChange={(e) => setZoneId(Number(e.target.value))}
                className="mt-1 w-full border border-slate-200 rounded-lg px-3 py-2.5 outline-none focus:border-teal"
              >
                {zones.map((z) => (
                  <option key={z.id} value={z.id}>
                    {z.name} {z.is_contact_only ? "— contact pharmacy" : `— ${formatTZS(z.fee)}`}
                  </option>
                ))}
              </select>
              {selectedZone?.description ? (
                <p className="text-xs text-slate-400 mt-1">{selectedZone.description}</p>
              ) : null}
            </div>

            {outsideArea ? (
              <div className="bg-amber-50 border border-amber-200 text-amber-800 text-sm rounded-lg p-3">
                This zone is outside our delivery area. Please{" "}
                <a href="https://wa.me/255700000000" className="underline font-medium" target="_blank" rel="noreferrer">
                  contact the pharmacy on WhatsApp
                </a>{" "}
                to arrange delivery, or choose collection instead.
              </div>
            ) : (
              <>
                <input
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  placeholder="Address / area (e.g. Njiro, House No. 12)"
                  className="w-full border border-slate-200 rounded-lg px-3 py-2.5 outline-none focus:border-teal"
                />
                <input
                  value={landmark}
                  onChange={(e) => setLandmark(e.target.value)}
                  placeholder="Nearby landmark (e.g. Near Njiro Complex) — optional"
                  className="w-full border border-slate-200 rounded-lg px-3 py-2.5 outline-none focus:border-teal"
                />
                <textarea
                  value={instructions}
                  onChange={(e) => setInstructions(e.target.value)}
                  placeholder="Delivery instructions — optional"
                  rows={2}
                  className="w-full border border-slate-200 rounded-lg px-3 py-2.5 outline-none focus:border-teal"
                />
              </>
            )}
          </div>
        ) : (
          <div className="bg-slate-50 border border-slate-200 rounded-lg p-3 text-sm text-slate-600">
            Collect from: <span className="font-medium">Simbeye Pharmacy — main branch.</span> We'll notify you when
            your order is ready.
          </div>
        )}
      </section>

      {/* Prescription upload */}
      {hasPrescriptionItems ? (
        <section className="bg-white rounded-xl border border-slate-100 p-5 mb-4">
          <h2 className="font-semibold text-slate mb-2">📋 Upload your prescription</h2>
          <p className="text-sm text-slate-500 mb-3">
            Your cart contains prescription medicine(s). Our pharmacist will review your order before it's prepared.
          </p>
          <label className="flex items-center justify-center gap-2 border-2 border-dashed border-slate-200 rounded-lg py-6 cursor-pointer hover:border-teal text-slate-500 text-sm">
            {prescriptionFile ? `✓ ${prescriptionFile.name}` : "📷 Take photo / 📁 Upload prescription (JPG, PNG or PDF)"}
            <input
              type="file"
              accept="image/jpeg,image/png,application/pdf"
              className="hidden"
              onChange={(e) => setPrescriptionFile(e.target.files?.[0] || null)}
            />
          </label>
        </section>
      ) : null}

      {/* Order summary + Payment */}
      <section className="bg-white rounded-xl border border-slate-100 p-5 mb-4">
        <h2 className="font-semibold text-slate mb-3">3. Payment</h2>
        <div className="grid grid-cols-3 gap-2 mb-4">
          {([
            ["mobile_money", "📱", "Mobile Money"],
            ["card", "💳", "Card"],
            ["cash", "💵", fulfillment === "delivery" ? "Cash on Delivery" : "Cash on Collection"],
          ] as [PaymentMethod, string, string][]).map(([value, icon, label]) => (
            <button
              key={value}
              onClick={() => setPayment(value)}
              className={`border rounded-lg py-3 text-xs font-medium flex flex-col items-center gap-1 ${
                payment === value ? "border-teal bg-teal/10 text-teal" : "border-slate-200 text-slate-600"
              }`}
            >
              <span className="text-lg">{icon}</span>
              {label}
            </button>
          ))}
        </div>

        <div className="border-t border-slate-100 pt-4 space-y-1.5 text-sm">
          <div className="flex justify-between text-slate-600">
            <span>Medicines & products</span>
            <span>{formatTZS(subtotal)}</span>
          </div>
          <div className="flex justify-between text-slate-600">
            <span>Delivery</span>
            <span>{fulfillment === "collection" ? "Free (collection)" : formatTZS(deliveryFee)}</span>
          </div>
          <div className="flex justify-between font-display font-bold text-navy text-base pt-2 border-t border-slate-100 mt-2">
            <span>TOTAL TO PAY</span>
            <span>{formatTZS(total)}</span>
          </div>
        </div>
      </section>

      {error ? <p className="text-red text-sm mb-3">{error}</p> : null}

      <button
        disabled={!canSubmit}
        onClick={placeOrder}
        className="w-full bg-navy text-white font-semibold py-3.5 rounded-lg hover:bg-navy/90 disabled:bg-slate-200 disabled:text-slate-400"
      >
        {submitting ? processingLabel || "Placing order…" : `Place Order — ${formatTZS(total)}`}
      </button>
      <p className="text-xs text-slate-400 text-center mt-2">
        You'll see this exact total before paying — nothing changes after you place your order.
      </p>
    </div>
  );
}
