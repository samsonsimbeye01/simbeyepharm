import { useState } from "react";
import { useSearchParams } from "react-router-dom";
import { api } from "../lib/api";
import { formatTZS } from "../lib/format";

const STEPS_DELIVERY = [
  ["received", "Order received"],
  ["confirmed", "Confirmed"],
  ["preparing", "Preparing"],
  ["out_for_delivery", "Out for delivery"],
  ["delivered", "Delivered"],
];
const STEPS_COLLECTION = [
  ["received", "Order received"],
  ["confirmed", "Confirmed"],
  ["preparing", "Preparing"],
  ["ready_for_collection", "Ready for collection"],
  ["collected", "Collected"],
];

export function TrackOrder() {
  const [searchParams] = useSearchParams();
  const [orderNumber, setOrderNumber] = useState(searchParams.get("order") || "");
  const [phone, setPhone] = useState(searchParams.get("phone") || "");
  const [order, setOrder] = useState<any>(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const lookup = async (e?: React.FormEvent) => {
    e?.preventDefault();
    setError("");
    setLoading(true);
    try {
      const data = await api.trackOrder(orderNumber.trim(), phone.trim());
      setOrder(data);
    } catch (e: any) {
      setError(e.message);
      setOrder(null);
    } finally {
      setLoading(false);
    }
  };

  const steps = order?.fulfillment_type === "collection" ? STEPS_COLLECTION : STEPS_DELIVERY;
  const currentIndex = order ? steps.findIndex(([key]) => key === order.order_status) : -1;
  const cancelled = order?.order_status === "cancelled";
  const pharmacistReview = order?.order_status === "pharmacist_review";

  return (
    <div className="max-w-xl mx-auto px-4 py-10">
      <h1 className="font-display font-bold text-2xl text-slate mb-6">Track your order</h1>
      <form onSubmit={lookup} className="bg-white border border-slate-100 rounded-xl p-5 flex flex-col gap-3">
        <input
          value={orderNumber}
          onChange={(e) => setOrderNumber(e.target.value)}
          placeholder="Order number e.g. SP-1024"
          className="border border-slate-200 rounded-lg px-3 py-2.5 outline-none focus:border-teal"
        />
        <input
          value={phone}
          onChange={(e) => setPhone(e.target.value)}
          placeholder="Phone number used at checkout"
          className="border border-slate-200 rounded-lg px-3 py-2.5 outline-none focus:border-teal"
        />
        <button className="bg-navy text-white font-semibold py-2.5 rounded-lg hover:bg-navy/90" disabled={loading}>
          {loading ? "Looking up…" : "Track order"}
        </button>
      </form>

      {error ? <p className="text-red text-sm mt-4">{error}</p> : null}

      {order ? (
        <div className="bg-white border border-slate-100 rounded-xl p-5 mt-6">
          <p className="text-sm text-slate-500">
            Order <span className="font-semibold text-navy">{order.order_number}</span> &middot;{" "}
            {formatTZS(order.total)}
          </p>

          {pharmacistReview ? (
            <div className="mt-4 bg-amber-50 border border-amber-200 text-amber-800 text-sm rounded-lg p-3">
              🔎 Pharmacist reviewing your prescription. We'll notify you once it's approved.
            </div>
          ) : cancelled ? (
            <div className="mt-4 bg-red/10 border border-red/30 text-red text-sm rounded-lg p-3">
              This order was cancelled. Contact us on WhatsApp if you have questions.
            </div>
          ) : (
            <ol className="mt-5 space-y-3">
              {steps.map(([key, label], i) => {
                const done = i <= currentIndex;
                return (
                  <li key={key} className="flex items-center gap-3">
                    <span
                      className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${
                        done ? "bg-teal text-white" : "bg-slate-100 text-slate-400"
                      }`}
                    >
                      {done ? "✓" : i + 1}
                    </span>
                    <span className={done ? "text-slate font-medium" : "text-slate-400"}>{label}</span>
                  </li>
                );
              })}
            </ol>
          )}

          <div className="mt-5 pt-4 border-t border-slate-100 text-sm text-slate-600 space-y-1">
            <p>
              Payment: <span className="capitalize font-medium">{order.payment_method.replace("_", " ")}</span> —{" "}
              <span className={order.payment_status === "paid" ? "text-teal font-medium" : "text-amber-600 font-medium"}>
                {order.payment_status === "paid" ? "Paid" : "Pending"}
              </span>
            </p>
          </div>

          <a
            href="https://wa.me/255700000000"
            target="_blank"
            rel="noreferrer"
            className="inline-block mt-4 bg-[#25D366] text-white text-sm font-semibold px-4 py-2 rounded-lg hover:opacity-90"
          >
            💬 Need help with this order?
          </a>
        </div>
      ) : null}
    </div>
  );
}
