import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { api } from "../lib/api";
import type { Category } from "../lib/types";

export function Home() {
  const [categories, setCategories] = useState<Category[]>([]);
  const [query, setQuery] = useState("");
  const navigate = useNavigate();

  useEffect(() => {
    api.categories().then(setCategories).catch(() => {});
  }, []);

  const submitSearch = (e: React.FormEvent) => {
    e.preventDefault();
    navigate(`/shop${query ? `?search=${encodeURIComponent(query)}` : ""}`);
  };

  return (
    <div>
      <section className="bg-navy text-white">
        <div className="max-w-6xl mx-auto px-4 py-14 md:py-20 text-center">
          <h1 className="font-display font-extrabold text-3xl md:text-5xl leading-tight">
            Your health. Our priority.
          </h1>
          <p className="mt-4 text-slate-200 max-w-xl mx-auto">
            Order medicines and health products online and have them delivered to you — or collect from our pharmacy.
          </p>
          <form onSubmit={submitSearch} className="mt-8 max-w-xl mx-auto flex gap-2">
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="🔎 What are you looking for? e.g. Paracetamol, ORS..."
              className="flex-1 rounded-lg px-4 py-3 text-slate placeholder:text-slate-400 outline-none"
            />
            <button className="bg-teal font-semibold px-5 py-3 rounded-lg hover:bg-teal/90">Search</button>
          </form>
          <div className="mt-6 flex flex-wrap gap-3 justify-center">
            <Link to="/shop" className="bg-white/10 hover:bg-white/20 px-4 py-2 rounded-lg text-sm font-medium">
              🛒 Shop
            </Link>
            <Link to="/shop?rx=1" className="bg-white/10 hover:bg-white/20 px-4 py-2 rounded-lg text-sm font-medium">
              📋 Prescription Medicines
            </Link>
            <Link to="/track" className="bg-white/10 hover:bg-white/20 px-4 py-2 rounded-lg text-sm font-medium">
              📦 Track an Order
            </Link>
          </div>
        </div>
      </section>

      <section className="max-w-6xl mx-auto px-4 py-12">
        <h2 className="font-display font-bold text-xl text-slate mb-5">Shop by category</h2>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
          {categories.map((c) => (
            <Link
              key={c.id}
              to={`/shop?category=${c.slug}`}
              className="bg-white border border-slate-100 rounded-xl p-5 text-center hover:shadow-md hover:border-teal/40 transition-all"
            >
              <div className="text-3xl mb-2">{c.icon}</div>
              <div className="font-medium text-sm text-slate">{c.name}</div>
            </Link>
          ))}
        </div>
      </section>

      <section className="bg-offwhite border-y border-slate-100">
        <div className="max-w-6xl mx-auto px-4 py-12 grid md:grid-cols-3 gap-6 text-center">
          <div>
            <div className="text-3xl mb-2">🚚</div>
            <h3 className="font-semibold text-slate">Delivery or collection</h3>
            <p className="text-sm text-slate-500 mt-1">
              See your delivery fee before you pay — no surprises at checkout.
            </p>
          </div>
          <div>
            <div className="text-3xl mb-2">🔒</div>
            <h3 className="font-semibold text-slate">Pharmacist-reviewed prescriptions</h3>
            <p className="text-sm text-slate-500 mt-1">
              Upload your prescription; our pharmacist reviews before dispensing.
            </p>
          </div>
          <div>
            <div className="text-3xl mb-2">💬</div>
            <h3 className="font-semibold text-slate">Always reachable on WhatsApp</h3>
            <p className="text-sm text-slate-500 mt-1">Questions about a medicine or your order? Just message us.</p>
          </div>
        </div>
      </section>
    </div>
  );
}
