import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { adminApi } from "../../lib/api";

export function AdminLogin() {
  const [email, setEmail] = useState("admin@simbeye.co.tz");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      const { token } = await adminApi.login(email, password);
      localStorage.setItem("simbeye_admin_token", token);
      navigate("/admin");
    } catch (e: any) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-navy flex items-center justify-center px-4">
      <form onSubmit={submit} className="bg-white rounded-xl p-8 w-full max-w-sm shadow-xl">
        <div className="text-center mb-6">
          <span className="inline-block w-10 h-10 rounded-lg bg-teal text-white font-black flex items-center justify-center mx-auto mb-2">
            S
          </span>
          <h1 className="font-display font-bold text-lg text-slate">Simbeye Pharmacy Admin</h1>
        </div>
        <div className="space-y-3">
          <input
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="Email"
            className="w-full border border-slate-200 rounded-lg px-3 py-2.5 outline-none focus:border-teal"
          />
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="Password"
            className="w-full border border-slate-200 rounded-lg px-3 py-2.5 outline-none focus:border-teal"
          />
        </div>
        {error ? <p className="text-red text-sm mt-3">{error}</p> : null}
        <button
          disabled={loading}
          className="w-full mt-5 bg-navy text-white font-semibold py-2.5 rounded-lg hover:bg-navy/90"
        >
          {loading ? "Signing in…" : "Sign in"}
        </button>
        <p className="text-xs text-slate-400 mt-4 text-center">
          Demo: admin@simbeye.co.tz / simbeye2026
        </p>
      </form>
    </div>
  );
}
