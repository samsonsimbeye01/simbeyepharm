import { useEffect, useState } from "react";
import { adminApi } from "../../lib/api";
import { formatTZS } from "../../lib/format";

const emptyForm = {
  name: "",
  genericName: "",
  categoryId: "",
  strength: "",
  dosageForm: "",
  packSize: "",
  price: 0,
  stockQty: 0,
  reorderLevel: 10,
  requiresPrescription: false,
  imageColor: "#0F2C59",
  description: "",
};

export function AdminProducts() {
  const [products, setProducts] = useState<any[]>([]);
  const [categories, setCategories] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [editingId, setEditingId] = useState<number | "new" | null>(null);
  const [form, setForm] = useState<any>(emptyForm);
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);

  const load = () =>
    Promise.all([adminApi.products(), adminApi.categories()]).then(([p, c]) => {
      setProducts(p);
      setCategories(c);
      setLoading(false);
    });

  useEffect(() => {
    load();
  }, []);

  const openNew = () => {
    setForm(emptyForm);
    setEditingId("new");
    setError("");
  };

  const openEdit = (p: any) => {
    setForm({
      name: p.name,
      genericName: p.generic_name || "",
      categoryId: p.category_id,
      strength: p.strength || "",
      dosageForm: p.dosage_form || "",
      packSize: p.pack_size || "",
      price: p.price,
      stockQty: p.stock_qty,
      reorderLevel: p.reorder_level,
      requiresPrescription: !!p.requires_prescription,
      imageColor: p.image_color,
      description: p.description || "",
      active: !!p.active,
    });
    setEditingId(p.id);
    setError("");
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.categoryId) {
      setError("Please choose a category.");
      return;
    }
    setSaving(true);
    setError("");
    try {
      if (editingId === "new") {
        await adminApi.createProduct(form);
      } else if (editingId != null) {
        await adminApi.updateProduct(editingId, form);
      }
      setEditingId(null);
      await load();
    } catch (e: any) {
      setError(e.message);
    } finally {
      setSaving(false);
    }
  };

  const filtered = products.filter(
    (p) =>
      !search ||
      p.name.toLowerCase().includes(search.toLowerCase()) ||
      (p.generic_name || "").toLowerCase().includes(search.toLowerCase())
  );

  if (loading) return <div className="text-slate-500">Loading…</div>;

  return (
    <div>
      <div className="flex items-center justify-between mb-1">
        <h1 className="font-display font-bold text-2xl text-slate">Products</h1>
        <button onClick={openNew} className="bg-teal text-white text-sm font-semibold px-4 py-2 rounded-lg hover:bg-teal/90">
          + Add product
        </button>
      </div>
      <p className="text-slate-500 text-sm mb-4">{products.length} products in catalogue</p>

      <input
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        placeholder="Search products…"
        className="mb-4 w-full max-w-sm border border-slate-200 rounded-lg px-3 py-2 outline-none focus:border-teal"
      />

      {editingId != null ? (
        <form onSubmit={submit} className="bg-white rounded-xl border border-slate-100 p-5 mb-6 grid md:grid-cols-2 gap-3">
          <h2 className="md:col-span-2 font-display font-semibold text-slate">
            {editingId === "new" ? "New product" : "Edit product"}
          </h2>
          {error ? <p className="md:col-span-2 text-red text-sm">{error}</p> : null}
          <input
            required
            placeholder="Name"
            value={form.name}
            onChange={(e) => setForm({ ...form, name: e.target.value })}
            className="border border-slate-200 rounded-lg px-3 py-2 outline-none focus:border-teal"
          />
          <input
            placeholder="Generic name"
            value={form.genericName}
            onChange={(e) => setForm({ ...form, genericName: e.target.value })}
            className="border border-slate-200 rounded-lg px-3 py-2 outline-none focus:border-teal"
          />
          <select
            required
            value={form.categoryId}
            onChange={(e) => setForm({ ...form, categoryId: Number(e.target.value) })}
            className="border border-slate-200 rounded-lg px-3 py-2 outline-none focus:border-teal"
          >
            <option value="">Category…</option>
            {categories.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>
          <input
            placeholder="Strength e.g. 500mg"
            value={form.strength}
            onChange={(e) => setForm({ ...form, strength: e.target.value })}
            className="border border-slate-200 rounded-lg px-3 py-2 outline-none focus:border-teal"
          />
          <input
            placeholder="Dosage form e.g. Tablet"
            value={form.dosageForm}
            onChange={(e) => setForm({ ...form, dosageForm: e.target.value })}
            className="border border-slate-200 rounded-lg px-3 py-2 outline-none focus:border-teal"
          />
          <input
            placeholder="Pack size e.g. 10 tabs"
            value={form.packSize}
            onChange={(e) => setForm({ ...form, packSize: e.target.value })}
            className="border border-slate-200 rounded-lg px-3 py-2 outline-none focus:border-teal"
          />
          <input
            type="number"
            required
            placeholder="Price (TZS)"
            value={form.price}
            onChange={(e) => setForm({ ...form, price: Number(e.target.value) })}
            className="border border-slate-200 rounded-lg px-3 py-2 outline-none focus:border-teal"
          />
          <input
            type="number"
            placeholder="Stock quantity"
            value={form.stockQty}
            onChange={(e) => setForm({ ...form, stockQty: Number(e.target.value) })}
            className="border border-slate-200 rounded-lg px-3 py-2 outline-none focus:border-teal"
          />
          <input
            type="number"
            placeholder="Reorder level"
            value={form.reorderLevel}
            onChange={(e) => setForm({ ...form, reorderLevel: Number(e.target.value) })}
            className="border border-slate-200 rounded-lg px-3 py-2 outline-none focus:border-teal"
          />
          <input
            type="color"
            value={form.imageColor}
            onChange={(e) => setForm({ ...form, imageColor: e.target.value })}
            className="border border-slate-200 rounded-lg h-10 w-16"
            title="Placeholder swatch colour"
          />
          <label className="flex items-center gap-2 text-sm md:col-span-2">
            <input
              type="checkbox"
              checked={form.requiresPrescription}
              onChange={(e) => setForm({ ...form, requiresPrescription: e.target.checked })}
            />
            Requires prescription
          </label>
          {editingId !== "new" ? (
            <label className="flex items-center gap-2 text-sm md:col-span-2">
              <input
                type="checkbox"
                checked={form.active !== false}
                onChange={(e) => setForm({ ...form, active: e.target.checked })}
              />
              Active (visible in shop)
            </label>
          ) : null}
          <textarea
            placeholder="Description"
            value={form.description}
            onChange={(e) => setForm({ ...form, description: e.target.value })}
            className="border border-slate-200 rounded-lg px-3 py-2 outline-none focus:border-teal md:col-span-2"
          />
          <div className="md:col-span-2 flex gap-3">
            <button disabled={saving} className="bg-navy text-white font-semibold px-5 py-2 rounded-lg hover:bg-navy/90">
              {saving ? "Saving…" : "Save product"}
            </button>
            <button type="button" onClick={() => setEditingId(null)} className="text-slate-500 hover:underline">
              Cancel
            </button>
          </div>
        </form>
      ) : null}

      <div className="bg-white rounded-xl border border-slate-100 overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-slate-50 text-slate-500 text-left">
            <tr>
              <th className="px-4 py-3">Product</th>
              <th className="px-4 py-3">Category</th>
              <th className="px-4 py-3">Price</th>
              <th className="px-4 py-3">Stock</th>
              <th className="px-4 py-3">Rx</th>
              <th className="px-4 py-3"></th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {filtered.map((p) => (
              <tr key={p.id} className={p.active ? "" : "opacity-50"}>
                <td className="px-4 py-3 font-medium text-slate">
                  {p.name}
                  <div className="text-xs text-slate-400">{p.generic_name}</div>
                </td>
                <td className="px-4 py-3 text-slate-500">{p.category_name}</td>
                <td className="px-4 py-3">{formatTZS(p.price)}</td>
                <td className="px-4 py-3">
                  <span
                    className={
                      p.stock_qty === 0
                        ? "text-red font-semibold"
                        : p.stock_qty <= p.reorder_level
                        ? "text-amber-600 font-semibold"
                        : "text-slate"
                    }
                  >
                    {p.stock_qty}
                  </span>
                </td>
                <td className="px-4 py-3">{p.requires_prescription ? "Rx" : "—"}</td>
                <td className="px-4 py-3">
                  <button onClick={() => openEdit(p)} className="text-navy font-semibold hover:underline">
                    Edit
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
