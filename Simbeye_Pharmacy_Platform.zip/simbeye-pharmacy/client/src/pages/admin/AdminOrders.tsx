import { useEffect, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { adminApi } from "../../lib/api";
import { formatTZS } from "../../lib/format";

const STATUS_LABELS: Record<string, string> = {
  received: "Received",
  pharmacist_review: "Pharmacist review",
  confirmed: "Confirmed",
  preparing: "Preparing",
  out_for_delivery: "Out for delivery",
  ready_for_collection: "Ready for collection",
  delivered: "Delivered",
  collected: "Collected",
  cancelled: "Cancelled",
};

const VALID_TRANSITIONS: Record<string, string[]> = {
  received: ["pharmacist_review", "confirmed", "cancelled"],
  pharmacist_review: ["confirmed", "cancelled"],
  confirmed: ["preparing", "cancelled"],
  preparing: ["out_for_delivery", "ready_for_collection", "cancelled"],
  out_for_delivery: ["delivered", "cancelled"],
  ready_for_collection: ["collected", "cancelled"],
  delivered: [],
  collected: [],
  cancelled: [],
};

function StatusBadge({ status }: { status: string }) {
  const color =
    status === "cancelled"
      ? "bg-red/10 text-red"
      : status === "delivered" || status === "collected"
      ? "bg-teal/10 text-teal"
      : status === "pharmacist_review"
      ? "bg-amber-100 text-amber-700"
      : "bg-navy/10 text-navy";
  return <span className={`px-2 py-1 rounded-full text-xs font-semibold ${color}`}>{STATUS_LABELS[status] || status}</span>;
}

export function AdminOrders() {
  const [searchParams, setSearchParams] = useSearchParams();
  const statusFilter = searchParams.get("status") || "";
  const [orders, setOrders] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState<any>(null);
  const [detailLoading, setDetailLoading] = useState(false);
  const [actionError, setActionError] = useState("");

  const load = () =>
    adminApi
      .orders(statusFilter || undefined)
      .then(setOrders)
      .finally(() => setLoading(false));

  useEffect(() => {
    setLoading(true);
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [statusFilter]);

  const openOrder = async (id: number) => {
    setDetailLoading(true);
    setActionError("");
    try {
      const data = await adminApi.order(id);
      setSelected(data);
    } finally {
      setDetailLoading(false);
    }
  };

  const changeStatus = async (status: string) => {
    if (!selected) return;
    setActionError("");
    try {
      await adminApi.updateOrderStatus(selected.id, status);
      await openOrder(selected.id);
      load();
    } catch (e: any) {
      setActionError(e.message);
    }
  };

  const changePayment = async (paymentStatus: string) => {
    if (!selected) return;
    setActionError("");
    try {
      await adminApi.updatePaymentStatus(selected.id, paymentStatus);
      await openOrder(selected.id);
      load();
    } catch (e: any) {
      setActionError(e.message);
    }
  };

  return (
    <div>
      <h1 className="font-display font-bold text-2xl text-slate mb-1">Orders</h1>
      <p className="text-slate-500 text-sm mb-4">{orders.length} order(s){statusFilter ? ` · filtered by ${STATUS_LABELS[statusFilter] || statusFilter}` : ""}</p>

      <div className="flex flex-wrap gap-2 mb-5">
        <button
          onClick={() => setSearchParams({})}
          className={`text-xs font-semibold px-3 py-1.5 rounded-full border ${
            !statusFilter ? "bg-navy text-white border-navy" : "border-slate-200 text-slate-500"
          }`}
        >
          All
        </button>
        {Object.entries(STATUS_LABELS).map(([key, label]) => (
          <button
            key={key}
            onClick={() => setSearchParams({ status: key })}
            className={`text-xs font-semibold px-3 py-1.5 rounded-full border ${
              statusFilter === key ? "bg-navy text-white border-navy" : "border-slate-200 text-slate-500"
            }`}
          >
            {label}
          </button>
        ))}
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl border border-slate-100 overflow-hidden">
          {loading ? (
            <div className="p-5 text-slate-500">Loading…</div>
          ) : orders.length === 0 ? (
            <div className="p-5 text-slate-400 text-sm">No orders match this filter.</div>
          ) : (
            <table className="w-full text-sm">
              <thead className="bg-slate-50 text-slate-500 text-left">
                <tr>
                  <th className="px-4 py-3">Order</th>
                  <th className="px-4 py-3">Customer</th>
                  <th className="px-4 py-3">Total</th>
                  <th className="px-4 py-3">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {orders.map((o) => (
                  <tr
                    key={o.id}
                    onClick={() => openOrder(o.id)}
                    className={`cursor-pointer hover:bg-slate-50 ${selected?.id === o.id ? "bg-slate-50" : ""}`}
                  >
                    <td className="px-4 py-3 font-medium text-navy">{o.order_number}</td>
                    <td className="px-4 py-3 text-slate-600">{o.customer_name}</td>
                    <td className="px-4 py-3">{formatTZS(o.total)}</td>
                    <td className="px-4 py-3">
                      <StatusBadge status={o.order_status} />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>

        <div className="bg-white rounded-xl border border-slate-100 p-5">
          {detailLoading ? (
            <p className="text-slate-500">Loading order…</p>
          ) : !selected ? (
            <p className="text-slate-400 text-sm">Select an order to view details.</p>
          ) : (
            <div>
              <div className="flex items-center justify-between">
                <h2 className="font-display font-bold text-lg text-navy">{selected.order_number}</h2>
                <StatusBadge status={selected.order_status} />
              </div>
              <p className="text-sm text-slate-500 mt-1">
                {selected.customer_name} · {selected.customer_phone}
              </p>
              <p className="text-sm text-slate-500 capitalize">
                {selected.fulfillment_type}
                {selected.address_text ? ` — ${selected.address_text}` : ""}
                {selected.landmark ? ` (${selected.landmark})` : ""}
              </p>
              {selected.has_prescription_items ? (
                <p className="text-xs text-red font-medium mt-1">Contains prescription-only items</p>
              ) : null}

              <ul className="mt-4 divide-y divide-slate-100 text-sm">
                {selected.items?.map((it: any) => (
                  <li key={it.id} className="py-2 flex justify-between">
                    <span>
                      {it.product_name} × {it.qty}
                    </span>
                    <span>{formatTZS(it.line_total)}</span>
                  </li>
                ))}
              </ul>

              <div className="mt-3 pt-3 border-t border-slate-100 text-sm space-y-1">
                <p className="flex justify-between">
                  <span className="text-slate-500">Subtotal</span> <span>{formatTZS(selected.subtotal)}</span>
                </p>
                <p className="flex justify-between">
                  <span className="text-slate-500">Delivery fee</span> <span>{formatTZS(selected.delivery_fee)}</span>
                </p>
                <p className="flex justify-between font-semibold text-navy">
                  <span>Total</span> <span>{formatTZS(selected.total)}</span>
                </p>
              </div>

              <div className="mt-4 pt-4 border-t border-slate-100">
                <p className="text-xs uppercase tracking-wide text-slate-400 font-medium mb-1">Payment</p>
                <p className="text-sm capitalize mb-2">
                  {selected.payment_method.replace("_", " ")} —{" "}
                  <span className={selected.payment_status === "paid" ? "text-teal font-semibold" : "text-amber-600 font-semibold"}>
                    {selected.payment_status}
                  </span>
                </p>
                <div className="flex gap-2 flex-wrap">
                  {["pending", "paid", "failed"]
                    .filter((s) => s !== selected.payment_status)
                    .map((s) => (
                      <button
                        key={s}
                        onClick={() => changePayment(s)}
                        className="text-xs border border-slate-200 rounded-full px-3 py-1 hover:bg-slate-50 capitalize"
                      >
                        Mark {s}
                      </button>
                    ))}
                </div>
              </div>

              <div className="mt-4 pt-4 border-t border-slate-100">
                <p className="text-xs uppercase tracking-wide text-slate-400 font-medium mb-2">Move status</p>
                <div className="flex gap-2 flex-wrap">
                  {(VALID_TRANSITIONS[selected.order_status] || []).length === 0 ? (
                    <p className="text-xs text-slate-400">This order is in a final state.</p>
                  ) : (
                    VALID_TRANSITIONS[selected.order_status].map((s) => (
                      <button
                        key={s}
                        onClick={() => changeStatus(s)}
                        className={`text-xs font-semibold px-3 py-1.5 rounded-full ${
                          s === "cancelled" ? "bg-red/10 text-red" : "bg-teal/10 text-teal"
                        } hover:opacity-80`}
                      >
                        {STATUS_LABELS[s]}
                      </button>
                    ))
                  )}
                </div>
                {actionError ? <p className="text-red text-xs mt-2">{actionError}</p> : null}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
