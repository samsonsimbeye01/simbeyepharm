import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { adminApi } from "../../lib/api";
import { formatTZS } from "../../lib/format";

interface Overview {
  ordersToday: number;
  salesToday: number;
  pendingOrders: number;
  outForDelivery: number;
  readyForCollection: number;
  lowStockCount: number;
  expiringCount: number;
  pendingPrescriptions: number;
}

function StatCard({ label, value, to, accent }: { label: string; value: string | number; to?: string; accent?: string }) {
  const inner = (
    <div className="bg-white rounded-xl border border-slate-100 p-5">
      <p className="text-xs uppercase tracking-wide text-slate-400 font-medium">{label}</p>
      <p className={`mt-2 text-2xl font-display font-bold ${accent || "text-navy"}`}>{value}</p>
    </div>
  );
  return to ? (
    <Link to={to} className="block hover:-translate-y-0.5 transition-transform">
      {inner}
    </Link>
  ) : (
    inner
  );
}

export function AdminDashboard() {
  const [data, setData] = useState<Overview | null>(null);
  const [lowStock, setLowStock] = useState<any[]>([]);
  const [expiring, setExpiring] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([adminApi.overview(), adminApi.lowStock(), adminApi.expiring()])
      .then(([ov, ls, ex]) => {
        setData(ov);
        setLowStock(ls);
        setExpiring(ex);
      })
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <div className="text-slate-500">Loading…</div>;
  if (!data) return <div className="text-red">Could not load dashboard.</div>;

  return (
    <div>
      <h1 className="font-display font-bold text-2xl text-slate mb-1">Today</h1>
      <p className="text-slate-500 text-sm mb-6">Overview of pharmacy activity, {new Date().toLocaleDateString()}</p>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatCard label="Orders today" value={data.ordersToday} to="/admin/orders" />
        <StatCard label="Sales today" value={formatTZS(data.salesToday)} accent="text-teal" />
        <StatCard label="Pending orders" value={data.pendingOrders} to="/admin/orders?status=received" />
        <StatCard label="Out for delivery" value={data.outForDelivery} to="/admin/orders?status=out_for_delivery" />
        <StatCard label="Ready for collection" value={data.readyForCollection} to="/admin/orders?status=ready_for_collection" />
        <StatCard label="Low stock items" value={data.lowStockCount} to="/admin/products" accent="text-amber-600" />
        <StatCard label="Expiring within 90 days" value={data.expiringCount} accent="text-amber-600" />
        <StatCard
          label="Pending prescriptions"
          value={data.pendingPrescriptions}
          to="/admin/prescriptions"
          accent="text-red"
        />
      </div>

      <div className="grid md:grid-cols-2 gap-6 mt-8">
        <div className="bg-white rounded-xl border border-slate-100 p-5">
          <h2 className="font-display font-semibold text-slate mb-3">Low stock</h2>
          {lowStock.length === 0 ? (
            <p className="text-sm text-slate-400">All products are above their reorder level.</p>
          ) : (
            <ul className="divide-y divide-slate-100">
              {lowStock.slice(0, 8).map((p) => (
                <li key={p.id} className="py-2 flex items-center justify-between text-sm">
                  <span className="text-slate">{p.name}</span>
                  <span className={p.stock_qty === 0 ? "text-red font-semibold" : "text-amber-600 font-semibold"}>
                    {p.stock_qty === 0 ? "Out of stock" : `${p.stock_qty} left`}
                  </span>
                </li>
              ))}
            </ul>
          )}
          <Link to="/admin/products" className="inline-block mt-3 text-teal text-sm font-medium hover:underline">
            Manage products →
          </Link>
        </div>

        <div className="bg-white rounded-xl border border-slate-100 p-5">
          <h2 className="font-display font-semibold text-slate mb-3">Expiring soon</h2>
          {expiring.length === 0 ? (
            <p className="text-sm text-slate-400">No batches expiring within 90 days.</p>
          ) : (
            <ul className="divide-y divide-slate-100">
              {expiring.slice(0, 8).map((b) => (
                <li key={b.id} className="py-2 flex items-center justify-between text-sm">
                  <span className="text-slate">
                    {b.product_name} <span className="text-slate-400">({b.batch_number})</span>
                  </span>
                  <span className="text-amber-600 font-semibold">{b.expiry_date}</span>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
    </div>
  );
}
