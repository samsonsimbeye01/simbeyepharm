import { useEffect, useState } from "react";
import { adminApi } from "../../lib/api";

export function AdminPrescriptions() {
  const [status, setStatus] = useState("pending");
  const [items, setItems] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [notes, setNotes] = useState<Record<number, string>>({});
  const [busyId, setBusyId] = useState<number | null>(null);
  const [error, setError] = useState("");

  const load = () =>
    adminApi
      .prescriptions(status || undefined)
      .then(setItems)
      .finally(() => setLoading(false));

  useEffect(() => {
    setLoading(true);
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [status]);

  const review = async (id: number, decision: "approved" | "rejected") => {
    setBusyId(id);
    setError("");
    try {
      await adminApi.reviewPrescription(id, decision, notes[id]);
      await load();
    } catch (e: any) {
      setError(e.message);
    } finally {
      setBusyId(null);
    }
  };

  return (
    <div>
      <h1 className="font-display font-bold text-2xl text-slate mb-1">Prescriptions</h1>
      <p className="text-slate-500 text-sm mb-4">
        Review uploaded prescriptions before a linked order is confirmed. Approving or rejecting a prescription automatically
        updates the customer's order status.
      </p>

      <div className="flex gap-2 mb-5">
        {["pending", "approved", "rejected", ""].map((s) => (
          <button
            key={s || "all"}
            onClick={() => setStatus(s)}
            className={`text-xs font-semibold px-3 py-1.5 rounded-full border capitalize ${
              status === s ? "bg-navy text-white border-navy" : "border-slate-200 text-slate-500"
            }`}
          >
            {s || "All"}
          </button>
        ))}
      </div>

      {error ? <p className="text-red text-sm mb-3">{error}</p> : null}

      {loading ? (
        <p className="text-slate-500">Loading…</p>
      ) : items.length === 0 ? (
        <p className="text-slate-400 text-sm">No prescriptions in this queue.</p>
      ) : (
        <div className="grid md:grid-cols-2 gap-4">
          {items.map((rx) => (
            <div key={rx.id} className="bg-white rounded-xl border border-slate-100 p-4">
              <div className="flex items-center justify-between">
                <p className="font-medium text-slate">{rx.customer_phone}</p>
                <span
                  className={`text-xs font-semibold px-2 py-1 rounded-full capitalize ${
                    rx.status === "pending"
                      ? "bg-amber-100 text-amber-700"
                      : rx.status === "approved"
                      ? "bg-teal/10 text-teal"
                      : "bg-red/10 text-red"
                  }`}
                >
                  {rx.status}
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-1">
                Uploaded {new Date(rx.created_at).toLocaleString()}
                {rx.order_id ? ` · linked to order #${rx.order_id}` : " · no linked order"}
              </p>

              <a
                href={rx.file_path}
                target="_blank"
                rel="noreferrer"
                className="inline-block mt-3 text-sm text-teal font-medium hover:underline"
              >
                View uploaded file →
              </a>

              {rx.pharmacist_notes ? (
                <p className="mt-2 text-xs text-slate-500 italic">Notes: {rx.pharmacist_notes}</p>
              ) : null}

              {rx.status === "pending" ? (
                <div className="mt-3 pt-3 border-t border-slate-100">
                  <input
                    placeholder="Notes (optional)"
                    value={notes[rx.id] || ""}
                    onChange={(e) => setNotes({ ...notes, [rx.id]: e.target.value })}
                    className="w-full border border-slate-200 rounded-lg px-3 py-1.5 text-sm outline-none focus:border-teal mb-2"
                  />
                  <div className="flex gap-2">
                    <button
                      disabled={busyId === rx.id}
                      onClick={() => review(rx.id, "approved")}
                      className="flex-1 bg-teal text-white text-sm font-semibold py-1.5 rounded-lg hover:bg-teal/90"
                    >
                      Approve
                    </button>
                    <button
                      disabled={busyId === rx.id}
                      onClick={() => review(rx.id, "rejected")}
                      className="flex-1 bg-red text-white text-sm font-semibold py-1.5 rounded-lg hover:bg-red/90"
                    >
                      Reject
                    </button>
                  </div>
                </div>
              ) : null}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
