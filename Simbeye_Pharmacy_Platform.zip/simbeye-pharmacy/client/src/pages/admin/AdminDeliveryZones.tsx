import { useEffect, useState } from "react";
import { adminApi } from "../../lib/api";
import { formatTZS } from "../../lib/format";
import type { DeliveryZone } from "../../lib/types";

const emptyForm = { name: "", description: "", fee: 0, isContactOnly: false, active: true, sortOrder: 99 };

export function AdminDeliveryZones() {
  const [zones, setZones] = useState<DeliveryZone[]>([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState<Record<number, any>>({});
  const [savingId, setSavingId] = useState<number | null>(null);
  const [creating, setCreating] = useState(false);
  const [form, setForm] = useState<any>(emptyForm);
  const [error, setError] = useState("");

  const load = () => adminApi.deliveryZones().then(setZones).finally(() => setLoading(false));
  useEffect(() => {
    load();
  }, []);

  const startEdit = (z: DeliveryZone) =>
    setEditing((e) => ({
      ...e,
      [z.id]: { name: z.name, description: z.description || "", fee: z.fee, isContactOnly: !!z.is_contact_only, active: !!z.active },
    }));

  const save = async (id: number) => {
    setSavingId(id);
    setError("");
    try {
      await adminApi.updateDeliveryZone(id, editing[id]);
      const next = { ...editing };
      delete next[id];
      setEditing(next);
      await load();
    } catch (e: any) {
      setError(e.message);
    } finally {
      setSavingId(null);
    }
  };

  const createZone = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    try {
      await adminApi.createDeliveryZone(form);
      setForm(emptyForm);
      setCreating(false);
      await load();
    } catch (e: any) {
      setError(e.message);
    }
  };

  if (loading) return <div className="text-slate-500">Loading…</div>;

  return (
    <div>
      <div className="flex items-center justify-between mb-1">
        <h1 className="font-display font-bold text-2xl text-slate">Delivery zones</h1>
        <button
          onClick={() => setCreating((c) => !c)}
          className="bg-teal text-white text-sm font-semibold px-4 py-2 rounded-lg hover:bg-teal/90"
        >
          {creating ? "Cancel" : "+ Add zone"}
        </button>
      </div>
      <p className="text-slate-500 text-sm mb-6">
        These fees are shown to customers at checkout before payment. Changes here apply immediately — no code changes needed.
      </p>

      {error ? <p className="text-red text-sm mb-4">{error}</p> : null}

      {creating ? (
        <form onSubmit={createZone} className="bg-white rounded-xl border border-slate-100 p-5 mb-6 grid gap-3 max-w-md">
          <input
            required
            placeholder="Zone name e.g. Zone D — Far suburbs"
            value={form.name}
            onChange={(e) => setForm({ ...form, name: e.target.value })}
            className="border border-slate-200 rounded-lg px-3 py-2 outline-none focus:border-teal"
          />
          <input
            placeholder="Description (optional)"
            value={form.description}
            onChange={(e) => setForm({ ...form, description: e.target.value })}
            className="border border-slate-200 rounded-lg px-3 py-2 outline-none focus:border-teal"
          />
          <label className="flex items-center gap-2 text-sm">
            <input
              type="checkbox"
              checked={form.isContactOnly}
              onChange={(e) => setForm({ ...form, isContactOnly: e.target.checked })}
            />
            Outside delivery area (contact pharmacy only, no fee)
          </label>
          {!form.isContactOnly && (
            <input
              type="number"
              placeholder="Fee (TZS)"
              value={form.fee}
              onChange={(e) => setForm({ ...form, fee: Number(e.target.value) })}
              className="border border-slate-200 rounded-lg px-3 py-2 outline-none focus:border-teal"
            />
          )}
          <button className="bg-navy text-white font-semibold py-2 rounded-lg hover:bg-navy/90">Create zone</button>
        </form>
      ) : null}

      <div className="bg-white rounded-xl border border-slate-100 overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-slate-50 text-slate-500 text-left">
            <tr>
              <th className="px-4 py-3">Zone</th>
              <th className="px-4 py-3">Description</th>
              <th className="px-4 py-3">Fee</th>
              <th className="px-4 py-3">Active</th>
              <th className="px-4 py-3"></th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {zones.map((z) => {
              const e = editing[z.id];
              return (
                <tr key={z.id}>
                  {e ? (
                    <>
                      <td className="px-4 py-2">
                        <input
                          value={e.name}
                          onChange={(ev) => setEditing({ ...editing, [z.id]: { ...e, name: ev.target.value } })}
                          className="border border-slate-200 rounded px-2 py-1 w-full"
                        />
                      </td>
                      <td className="px-4 py-2">
                        <input
                          value={e.description}
                          onChange={(ev) => setEditing({ ...editing, [z.id]: { ...e, description: ev.target.value } })}
                          className="border border-slate-200 rounded px-2 py-1 w-full"
                        />
                      </td>
                      <td className="px-4 py-2">
                        {e.isContactOnly ? (
                          <span className="text-slate-400">Contact only</span>
                        ) : (
                          <input
                            type="number"
                            value={e.fee}
                            onChange={(ev) => setEditing({ ...editing, [z.id]: { ...e, fee: Number(ev.target.value) } })}
                            className="border border-slate-200 rounded px-2 py-1 w-24"
                          />
                        )}
                      </td>
                      <td className="px-4 py-2">
                        <input
                          type="checkbox"
                          checked={e.active}
                          onChange={(ev) => setEditing({ ...editing, [z.id]: { ...e, active: ev.target.checked } })}
                        />
                      </td>
                      <td className="px-4 py-2 whitespace-nowrap">
                        <button
                          disabled={savingId === z.id}
                          onClick={() => save(z.id)}
                          className="text-teal font-semibold mr-3 hover:underline"
                        >
                          Save
                        </button>
                        <button
                          onClick={() => {
                            const next = { ...editing };
                            delete next[z.id];
                            setEditing(next);
                          }}
                          className="text-slate-400 hover:underline"
                        >
                          Cancel
                        </button>
                      </td>
                    </>
                  ) : (
                    <>
                      <td className="px-4 py-3 font-medium text-slate">{z.name}</td>
                      <td className="px-4 py-3 text-slate-500">{z.description || "—"}</td>
                      <td className="px-4 py-3 font-medium">
                        {z.is_contact_only ? <span className="text-slate-400">Contact pharmacy</span> : formatTZS(z.fee)}
                      </td>
                      <td className="px-4 py-3">
                        {z.active ? (
                          <span className="text-teal font-medium">Active</span>
                        ) : (
                          <span className="text-slate-400">Inactive</span>
                        )}
                      </td>
                      <td className="px-4 py-3">
                        <button onClick={() => startEdit(z)} className="text-navy font-semibold hover:underline">
                          Edit
                        </button>
                      </td>
                    </>
                  )}
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
