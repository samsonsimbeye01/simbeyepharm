import { useEffect, useState } from "react";
import { NavLink, Outlet, useNavigate } from "react-router-dom";
import { adminApi } from "../../lib/api";
import type { StaffSession } from "../../lib/types";

const NAV = [
  { to: "/admin", label: "Overview", end: true },
  { to: "/admin/orders", label: "Orders" },
  { to: "/admin/prescriptions", label: "Prescriptions" },
  { to: "/admin/products", label: "Products" },
  { to: "/admin/delivery-zones", label: "Delivery Zones" },
];

export function AdminLayout() {
  const [staff, setStaff] = useState<StaffSession | null>(null);
  const [checking, setChecking] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    const token = localStorage.getItem("simbeye_admin_token");
    if (!token) {
      navigate("/admin/login");
      return;
    }
    adminApi
      .me()
      .then(setStaff)
      .catch(() => {
        localStorage.removeItem("simbeye_admin_token");
        navigate("/admin/login");
      })
      .finally(() => setChecking(false));
  }, [navigate]);

  const logout = async () => {
    await adminApi.logout().catch(() => {});
    localStorage.removeItem("simbeye_admin_token");
    navigate("/admin/login");
  };

  if (checking) return <div className="p-10 text-center text-slate-500">Loading…</div>;
  if (!staff) return null;

  return (
    <div className="min-h-screen bg-offwhite flex">
      <aside className="w-56 bg-navy text-white flex-shrink-0 flex flex-col">
        <div className="p-5 font-display font-bold border-b border-white/10">SIMBEYE ADMIN</div>
        <nav className="flex-1 py-4">
          {NAV.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.end}
              className={({ isActive }) =>
                `block px-5 py-2.5 text-sm font-medium ${isActive ? "bg-white/10 text-teal" : "text-slate-200 hover:bg-white/5"}`
              }
            >
              {item.label}
            </NavLink>
          ))}
        </nav>
        <div className="p-5 border-t border-white/10 text-xs">
          <p className="font-medium">{staff.name}</p>
          <p className="text-slate-400 capitalize">{staff.role.replace("_", " ")}</p>
          <button onClick={logout} className="mt-2 text-teal hover:underline">
            Sign out
          </button>
        </div>
      </aside>
      <main className="flex-1 p-6 md:p-8 overflow-x-auto">
        <Outlet context={{ staff }} />
      </main>
    </div>
  );
}
