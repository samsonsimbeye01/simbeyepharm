import { Link } from "react-router-dom";
import type { Product } from "../lib/types";
import { formatTZS } from "../lib/format";
import { StockBadge } from "./StockBadge";
import { useCart } from "../store/CartContext";

export function ProductCard({ product }: { product: Product }) {
  const { addItem } = useCart();
  const initials = product.name
    .split(" ")
    .slice(0, 2)
    .map((w) => w[0])
    .join("")
    .toUpperCase();

  return (
    <div className="bg-white rounded-xl border border-slate-100 shadow-sm hover:shadow-md transition-shadow flex flex-col overflow-hidden">
      <Link to={`/product/${product.id}`} className="block">
        <div
          className="h-28 flex items-center justify-center text-white font-display font-bold text-2xl"
          style={{ backgroundColor: product.image_color }}
        >
          {initials}
        </div>
      </Link>
      <div className="p-3 flex flex-col gap-1.5 flex-1">
        {product.requires_prescription ? (
          <span className="text-[11px] font-semibold text-navy bg-navy/10 px-2 py-0.5 rounded-full w-fit">
            🔒 Prescription required
          </span>
        ) : null}
        <Link to={`/product/${product.id}`} className="font-semibold text-slate text-sm leading-snug hover:text-teal">
          {product.name}
        </Link>
        {product.dosage_form ? <p className="text-xs text-slate-500">{product.dosage_form}</p> : null}
        <div className="mt-auto flex flex-col gap-2 pt-1">
          <StockBadge stock={product.stock_qty} reorderLevel={product.reorder_level} />
          <div className="flex items-center justify-between">
            <span className="font-display font-bold text-navy">{formatTZS(product.price)}</span>
            <button
              disabled={product.stock_qty <= 0}
              onClick={() => addItem(product, 1)}
              className="text-xs font-semibold bg-teal text-white px-3 py-1.5 rounded-lg hover:bg-teal/90 disabled:bg-slate-200 disabled:text-slate-400 disabled:cursor-not-allowed"
            >
              {product.stock_qty <= 0 ? "Notify me" : "Add to cart"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
