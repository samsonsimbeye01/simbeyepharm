export function StockBadge({ stock, reorderLevel }: { stock: number; reorderLevel: number }) {
  if (stock <= 0) {
    return (
      <span className="inline-flex items-center gap-1 text-xs font-semibold text-red bg-red/10 px-2 py-1 rounded-full">
        🔴 Out of stock
      </span>
    );
  }
  if (stock <= reorderLevel) {
    return (
      <span className="inline-flex items-center gap-1 text-xs font-semibold text-amber-700 bg-amber-100 px-2 py-1 rounded-full">
        🟠 Low stock — {stock} left
      </span>
    );
  }
  return (
    <span className="inline-flex items-center gap-1 text-xs font-semibold text-teal bg-teal/10 px-2 py-1 rounded-full">
      🟢 In stock — {stock} available
    </span>
  );
}
