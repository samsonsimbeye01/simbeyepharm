import { Link, NavLink, Outlet } from "react-router-dom";
import { useCart } from "../store/CartContext";

const PHARMACY_WHATSAPP = "255700000000"; // placeholder — replace with the real Simbeye Pharmacy WhatsApp number

export function Layout() {
  const { itemCount } = useCart();

  return (
    <div className="min-h-screen flex flex-col">
      <header className="bg-navy text-white sticky top-0 z-40 shadow-sm">
        <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between gap-4">
          <Link to="/" className="font-display font-extrabold tracking-wide text-lg flex items-center gap-2">
            <span className="inline-block w-8 h-8 rounded-md bg-teal flex items-center justify-center text-navy font-black">
              S
            </span>
            SIMBEYE PHARMACY
          </Link>
          <nav className="hidden md:flex items-center gap-6 text-sm font-medium">
            <NavLink to="/" end className={({ isActive }) => (isActive ? "text-teal" : "hover:text-teal")}>
              Home
            </NavLink>
            <NavLink to="/shop" className={({ isActive }) => (isActive ? "text-teal" : "hover:text-teal")}>
              Shop
            </NavLink>
            <NavLink to="/track" className={({ isActive }) => (isActive ? "text-teal" : "hover:text-teal")}>
              Track Order
            </NavLink>
            <a
              href={`https://wa.me/${PHARMACY_WHATSAPP}`}
              target="_blank"
              rel="noreferrer"
              className="hover:text-teal"
            >
              Talk to a Pharmacist
            </a>
          </nav>
          <Link
            to="/cart"
            className="relative inline-flex items-center gap-2 bg-teal text-white px-3 py-2 rounded-lg text-sm font-semibold hover:bg-teal/90"
          >
            🛒 Cart
            {itemCount > 0 ? (
              <span className="absolute -top-2 -right-2 bg-red text-white text-[11px] w-5 h-5 rounded-full flex items-center justify-center">
                {itemCount}
              </span>
            ) : null}
          </Link>
        </div>
      </header>

      <main className="flex-1">
        <Outlet />
      </main>

      <a
        href={`https://wa.me/${PHARMACY_WHATSAPP}`}
        target="_blank"
        rel="noreferrer"
        className="fixed bottom-5 right-5 z-40 bg-[#25D366] text-white w-14 h-14 rounded-full shadow-lg flex items-center justify-center text-2xl hover:scale-105 transition-transform"
        title="Chat with Simbeye Pharmacy on WhatsApp"
      >
        💬
      </a>

      <footer className="bg-slate text-slate-200 mt-12">
        <div className="max-w-6xl mx-auto px-4 py-8 text-sm flex flex-col md:flex-row justify-between gap-4">
          <div>
            <p className="font-display font-bold text-white">SIMBEYE PHARMACY</p>
            <p className="text-slate-400 mt-1">Reliable Healthcare. Within Reach.</p>
          </div>
          <div className="flex flex-col gap-1">
            <Link to="/admin/login" className="text-slate-400 hover:text-teal">
              Pharmacy staff login
            </Link>
            <span className="text-slate-500 text-xs mt-2">
              &copy; {new Date().getFullYear()} Simbeye Pharmacy. Demo platform — not a real transacting pharmacy.
            </span>
          </div>
        </div>
      </footer>
    </div>
  );
}
