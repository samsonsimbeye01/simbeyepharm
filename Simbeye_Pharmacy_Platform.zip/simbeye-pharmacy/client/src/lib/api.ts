const BASE = "/api";

async function request(path: string, options: RequestInit = {}) {
  const res = await fetch(`${BASE}${path}`, {
    ...options,
    headers: {
      ...(options.body && !(options.body instanceof FormData) ? { "Content-Type": "application/json" } : {}),
      ...(options.headers || {}),
    },
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(data.error || `Request failed (${res.status})`);
  }
  return data;
}

export const api = {
  categories: () => request("/categories"),
  products: (params: { search?: string; category?: string } = {}) => {
    const qs = new URLSearchParams();
    if (params.search) qs.set("search", params.search);
    if (params.category) qs.set("category", params.category);
    const suffix = qs.toString() ? `?${qs.toString()}` : "";
    return request(`/products${suffix}`);
  },
  product: (id: number | string) => request(`/products/${id}`),
  deliveryZones: () => request("/delivery-zones"),
  createOrder: (payload: any) => request("/orders", { method: "POST", body: JSON.stringify(payload) }),
  simulatePayment: (orderNumber: string) => request(`/orders/${orderNumber}/simulate-payment`, { method: "POST" }),
  trackOrder: (orderNumber: string, phone: string) =>
    request(`/orders/${encodeURIComponent(orderNumber)}?phone=${encodeURIComponent(phone)}`),
  uploadPrescription: (file: File, customerPhone: string, orderId?: number) => {
    const fd = new FormData();
    fd.append("file", file);
    fd.append("customerPhone", customerPhone);
    if (orderId) fd.append("orderId", String(orderId));
    return request("/prescriptions", { method: "POST", body: fd });
  },
};

function adminHeaders(): Record<string, string> {
  const token = localStorage.getItem("simbeye_admin_token");
  return token ? { Authorization: `Bearer ${token}` } : {};
}

export const adminApi = {
  login: (email: string, password: string) =>
    request("/admin/login", { method: "POST", body: JSON.stringify({ email, password }) }),
  logout: () => request("/admin/logout", { method: "POST", headers: adminHeaders() }),
  me: () => request("/admin/me", { headers: adminHeaders() }),
  overview: () => request("/admin/overview", { headers: adminHeaders() }),
  lowStock: () => request("/admin/low-stock", { headers: adminHeaders() }),
  expiring: () => request("/admin/expiring", { headers: adminHeaders() }),
  products: () => request("/admin/products", { headers: adminHeaders() }),
  categories: () => request("/admin/categories", { headers: adminHeaders() }),
  createProduct: (payload: any) =>
    request("/admin/products", { method: "POST", body: JSON.stringify(payload), headers: adminHeaders() }),
  updateProduct: (id: number, payload: any) =>
    request(`/admin/products/${id}`, { method: "PUT", body: JSON.stringify(payload), headers: adminHeaders() }),
  deliveryZones: () => request("/admin/delivery-zones", { headers: adminHeaders() }),
  updateDeliveryZone: (id: number, payload: any) =>
    request(`/admin/delivery-zones/${id}`, { method: "PUT", body: JSON.stringify(payload), headers: adminHeaders() }),
  createDeliveryZone: (payload: any) =>
    request(`/admin/delivery-zones`, { method: "POST", body: JSON.stringify(payload), headers: adminHeaders() }),
  orders: (status?: string) => request(`/admin/orders${status ? `?status=${status}` : ""}`, { headers: adminHeaders() }),
  order: (id: number) => request(`/admin/orders/${id}`, { headers: adminHeaders() }),
  updateOrderStatus: (id: number, status: string) =>
    request(`/admin/orders/${id}/status`, { method: "PUT", body: JSON.stringify({ status }), headers: adminHeaders() }),
  updatePaymentStatus: (id: number, paymentStatus: string) =>
    request(`/admin/orders/${id}/payment-status`, {
      method: "PUT",
      body: JSON.stringify({ paymentStatus }),
      headers: adminHeaders(),
    }),
  prescriptions: (status?: string) =>
    request(`/admin/prescriptions${status ? `?status=${status}` : ""}`, { headers: adminHeaders() }),
  reviewPrescription: (id: number, status: "approved" | "rejected", notes?: string) =>
    request(`/admin/prescriptions/${id}/review`, {
      method: "PUT",
      body: JSON.stringify({ status, notes }),
      headers: adminHeaders(),
    }),
};
