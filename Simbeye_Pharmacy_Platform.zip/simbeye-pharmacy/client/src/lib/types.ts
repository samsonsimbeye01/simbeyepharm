export interface Category {
  id: number;
  name: string;
  slug: string;
  icon: string;
}

export interface Product {
  id: number;
  name: string;
  generic_name: string | null;
  category_id: number;
  category_name: string;
  category_slug: string;
  dosage_form: string | null;
  pack_size: string | null;
  price: number;
  stock_qty: number;
  reorder_level: number;
  requires_prescription: number;
  image_color: string;
  description: string | null;
  active: number;
}

export interface DeliveryZone {
  id: number;
  name: string;
  description: string | null;
  fee: number;
  is_contact_only: number;
  active: number;
}

export interface CartLine {
  product: Product;
  qty: number;
}

export interface OrderResult {
  orderId: number;
  orderNumber: string;
  subtotal: number;
  deliveryFee: number;
  total: number;
  paymentStatus: string;
  orderStatus: string;
  hasPrescriptionItems: boolean;
}

export interface StaffSession {
  id: number;
  name: string;
  role: "super_admin" | "pharmacist" | "inventory_manager" | "cashier";
  email: string;
}
